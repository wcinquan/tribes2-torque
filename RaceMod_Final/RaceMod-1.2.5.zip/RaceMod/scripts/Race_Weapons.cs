//**************************************************************
// RACEMOD WEAPONS - MeBaD
//**************************************************************

//**************************************************************
// EMITTERS
//**************************************************************

	//**************************************************************
	// Smoke Screen Emitter
	//**************************************************************
		datablock ParticleData(SmokeScreenGunParticle) {
		    dragCoefficient = 3;
		    gravityCoefficient = -0.2;
		    windCoefficient = 2;
		    inheritedVelFactor = 1;
		    constantAcceleration = 0;
		    lifetimeMS = 7000;
		    lifetimeVarianceMS = 800;
		    useInvAlpha = 1;
		    spinRandomMin = -135;
		    spinRandomMax = 135;
		    textureName = "particleTest";
		    times[0] = 0;
		    times[1] = 1;
		    colors[0] = "1.000000 1.000000 1.000000 1.000000";
		    colors[1] = "0.700000 0.700000 0.700000 0.000000";
		    sizes[0] = 7.8;
		    sizes[1] = 8;
		};

		datablock ParticleEmitterData(SmokeScreenGunEmitter) {
		    ejectionPeriodMS = 19;
		    periodVarianceMS = 0;
		    ejectionVelocity = 3;
		    velocityVariance = 0;
		    ejectionOffset =   0;
		    thetaMin = 0;
		    thetaMax = 20;
		    phiReferenceVel = 0;
		    phiVariance = 360;
		    overrideAdvances = 0;
		    orientParticles= 0;
		    orientOnVelocity = 1;
		    particles = "SmokeScreenGunParticle";
		};


//**************************************************************
// PROJECTILES
//**************************************************************

	//**************************************************************
	// 2X Blasters Projectile
	//**************************************************************
		datablock TracerProjectileData(ScoutChaingunBullet) {
		   doDynamicClientHits = true;

		   directDamage        = 0.10; // was 0.125
		   explosion           = "ScoutChaingunExplosion";
		   splash              = ChaingunSplash;

		   directDamageType    = $DamageType::ShrikeBlaster;
		   kickBackStrength  = 0.0;

		   sound = ShrikeBlasterProjectileSound;

		   dryVelocity       = 425.0;
		   wetVelocity       = 100.0;
		   velInheritFactor  = 1.0;
		   fizzleTimeMS      = 1000;
		   lifetimeMS        = 1000;
		   explodeOnDeath    = false;
		   reflectOnWaterImpactAngle = 0.0;
		   explodeOnWaterImpact      = false;
		   deflectionOnWaterImpact   = 0.0;
		   fizzleUnderwaterMS        = 3000;

		   tracerLength    = 45.0;
		   tracerAlpha     = false;
		   tracerMinPixels = 6;
		   tracerColor     = "1.0 1.0 1.0 1.0";
			tracerTex[0]  	 = "special/shrikeBolt";
			tracerTex[1]  	 = "special/shrikeBoltCross";
			tracerWidth     = 0.55;
		   crossSize       = 0.99;
		   crossViewAng    = 0.990;
		   renderCross     = true;

		};

	//**************************************************************
	// Gatlin Gun Projectile
	//**************************************************************

		datablock TracerProjectileData(AssaultChaingunBullet) {
		   doDynamicClientHits = true;

		   projectileShapeName = "";
		   directDamage        = 0.09; // was 0.16
		   directDamageType    = $DamageType::TankChaingun;
		   hasDamageRadius     = false;
		   splash			   = ChaingunSplash;

		   kickbackstrength    = 0.0;
		   sound          	   = TankChaingunProjectile;

		   dryVelocity       = 425.0;
		   wetVelocity       = 100.0;
		   velInheritFactor  = 1.0;
		   fizzleTimeMS      = 3000;
		   lifetimeMS        = 3000;
		   explodeOnDeath    = false;
		   reflectOnWaterImpactAngle = 0.0;
		   explodeOnWaterImpact      = false;
		   deflectionOnWaterImpact   = 0.0;
		   fizzleUnderwaterMS        = 3000;

		   tracerLength    = 15.0;
		   tracerAlpha     = false;
		   tracerMinPixels = 6;
		   tracerColor     = 211.0/255.0 @ " " @ 215.0/255.0 @ " " @ 120.0/255.0 @ " 0.75";
			tracerTex[0]  	 = "special/tracer00";
			tracerTex[1]  	 = "special/tracercross";
			tracerWidth     = 0.10;
		   crossSize       = 0.20;
		   crossViewAng    = 0.990;
		   renderCross     = true;

		   decalData[0] = ChaingunDecal1;
		   decalData[1] = ChaingunDecal2;
		   decalData[2] = ChaingunDecal3;
		   decalData[3] = ChaingunDecal4;
		   decalData[4] = ChaingunDecal5;
		   decalData[5] = ChaingunDecal6;

		   activateDelayMS   = 100;

		   explosion = ChaingunExplosion;
		};

	//**************************************************************
	// Shockwave Gun Projectile
	//**************************************************************
		datablock GrenadeProjectileData(ShockwaveGunMortar) {
		   projectileShapeName = "mortar_projectile.dts";
		   emitterDelay        = -1;
		   directDamage        = 0.0;
		   hasDamageRadius     = true;
		   indirectDamage      = 0.2; // was 1.0
		   damageRadius        = 25.0;
		   radiusDamageType    = $DamageType::TankMortar;
		   kickBackStrength    = 2500;

		   sound          = MortarProjectileSound;
		//   explosion           = "MortarExplosion";
		   explosion           = "ConcussionGrenadeExplosion";
		   velInheritFactor    = 1.0;

		//   baseEmitter         = MortarSmokeEmitter;
		   baseEmitter         = ContrailEmitter;

		   grenadeElasticity = 0.3;
		   grenadeFriction   = 0.4;
		   armingDelayMS     = 250;
		   muzzleVelocity    = 65;
		   drag              = 0.1;

		   hasLight    = true;
		   lightRadius = 4;
		//   lightColor  = "0.1 0.4 0.1";
		   lightColor  = "0.1 0.4 0.1";
		};

	//**************************************************************
	// Bomber Gun Projectile
	//**************************************************************
		datablock BombProjectileData(BomberGunBomb) {
		   projectileShapeName  = "bomb.dts";
		   emitterDelay         = -1;
		   directDamage         = 0.0;
		   hasDamageRadius      = true;
		   indirectDamage       = 0.5; // was 1.1
		   damageRadius         = 35;  // was 30
		   radiusDamageType     = $DamageType::BomberBombs;
		   kickBackStrength     = 2500;

		   explosion            = "VehicleBombExplosion";
		   velInheritFactor     = 0.85; // was 1.0

		   grenadeElasticity    = 0.3;
		   grenadeFriction      = 0.4;
		   armingDelayMS        = 1000;
		   muzzleVelocity       = 0.1;
		   drag                 = 0.3;

		   minRotSpeed          = "60.0 0.0 0.0";
		   maxRotSpeed          = "80.0 0.0 0.0";
		   scale                = "1.0 1.0 1.0";
		   
		   sound                = BomberBombProjectileSound;
		};

	//**************************************************************
	// SmokeScreen Gun Projectile
	//**************************************************************
		datablock GrenadeProjectileData(SmokeScreenGunMortar) {
		   projectileShapeName = "mortar_projectile.dts";
		   emitterDelay        = -1;
		   directDamage        = 0.0;
		   hasDamageRadius     = true;
		   indirectDamage      = 0.1; // was 1.0
		   damageRadius        = 1.0;  // not really damage .. it's smoke
		   radiusDamageType    = $DamageType::TankMortar;
		   kickBackStrength    = 2500;

		   sound          = MortarProjectileSound;
		   explosion           = "MortarExplosion";
		   velInheritFactor    = 0.95;

		   //baseEmitter         = MortarSmokeEmitter;
		   baseEmitter         = SmokeScreenGunEmitter;

		   grenadeElasticity = 0.4;
		   grenadeFriction   = 0.1;
		   armingDelayMS     = 6000;
		   muzzleVelocity    = 65;
		   drag              = 0.0;

		   hasLight    = true;
		   lightRadius = 4;
		//   lightColor  = "0.1 0.4 0.1";
		   lightColor  = "0.4 0.1 0.1";
		};


//**************************************************************
// Weapon Images
//**************************************************************

	//**************************************************************
	// Gatlin Gun (Formally Tank chain)
	//**************************************************************
		datablock TurretData(AssaultPlasmaTurret) : TurretDamageProfile {
		   className      = VehicleTurret;
		   catagory       = "Turrets";
		   shapeFile      = "Turret_tank_base.dts";
		   preload        = true;

		   mass           = 1.0;  // Not really relevant

		   maxEnergy               = 1;
		   maxDamage               = AssaultVehicle.maxDamage;
		   destroyedLevel          = AssaultVehicle.destroyedLevel;
		   repairRate              = 0;
		   
		   // capacitor - not used anymore
		//   maxCapacitorEnergy      = 250;
		//   capacitorRechargeRate   = 1.0;

		   thetaMin = 0;
		   thetaMax = 100;

		   inheritEnergyFromMount = true;
		   firstPersonOnly = true;
		   useEyePoint = true;
		   numWeapons = 2;

		   cameraDefaultFov = 90.0;
		   cameraMinFov = 5.0;
		   cameraMaxFov = 120.0;

		   targetNameTag = 'Beowulf Chaingun';
		   targetTypeTag = 'Turret';
		};

		datablock TurretImageData(GatlinGunBarrel) {
		   shapeFile = "turret_tank_barrelchain.dts";
		   mountPoint = 1;

		   projectile = AssaultChaingunBullet;
		   projectileType = TracerProjectile;

		   casing              = ShellDebris;
		   shellExitDir        = "1.0 0.3 1.0";
		   shellExitOffset     = "0.15 -0.56 -0.1";
		   shellExitVariance   = 15.0;
		   shellVelocity       = 3.0;

		   projectileSpread = 6.0 / 1000.0; // was 12.0 / 1000.0

		   useCapacitor = false;
		   usesEnergy = true;
		   useMountEnergy = true;
		   fireEnergy = 5; // was 7.5
		   minEnergy = 15;

		   // Turret parameters
		   activationMS      = 4000;
		   deactivateDelayMS = 500;
		   thinkTimeMS       = 200;
		   degPerSecTheta    = 360;
		   degPerSecPhi      = 360;
		   attackRadius      = 75;

		   // State transitions
		   stateName[0]                        = "Activate";
		   stateTransitionOnNotLoaded[0]       = "Dead";
		   stateTransitionOnLoaded[0]          = "ActivateReady";
		   stateSound[0]                       = AssaultTurretActivateSound;

		   stateName[1]                        = "ActivateReady";
		   stateSequence[1]                    = "Activate";
		   stateSound[1]                       = AssaultTurretActivateSound;
		   stateTimeoutValue[1]                = 1;
		   stateTransitionOnTimeout[1]         = "Ready";
		   stateTransitionOnNotLoaded[1]       = "Deactivate";

		   stateName[2]                        = "Ready";
		   stateTransitionOnNotLoaded[2]       = "Deactivate";
		   stateTransitionOnTriggerDown[2]     = "Fire";
		   stateTransitionOnNoAmmo[2]          = "NoAmmo";

		   stateName[3]                        = "Fire";
		   stateSequence[3]                    = "Fire";
		   stateSequenceRandomFlash[3]         = true;
		   stateFire[3]                        = true;
		   stateAllowImageChange[3]            = false;
		   stateSound[3]                       = AssaultChaingunFireSound;
		   stateScript[3]                      = "onFire";
		   stateTimeoutValue[3]                = 0.1;
		   stateTransitionOnTimeout[3]         = "Fire";
		   stateTransitionOnTriggerUp[3]       = "Reload";
		   stateTransitionOnNoAmmo[3]          = "noAmmo";

		   stateName[4]                        = "Reload";
		   stateSequence[4]                    = "Reload";
		   stateTimeoutValue[4]                = 0.1;
		   stateAllowImageChange[4]            = false;
		   stateTransitionOnTimeout[4]         = "Ready";
		   stateTransitionOnNoAmmo[4]          = "NoAmmo";
		   stateWaitForTimeout[4]              = true;

		   stateName[5]                        = "Deactivate";
		   stateSequence[5]                    = "Activate";
		   stateDirection[5]                   = false;
		   stateTimeoutValue[5]                = 30;
		   stateTransitionOnTimeout[5]         = "ActivateReady";

		   stateName[6]                        = "Dead";
		   stateTransitionOnLoaded[6]          = "ActivateReady";
		   stateTransitionOnTriggerDown[6]     = "DryFire";

		   stateName[7]                        = "DryFire";
		   stateSound[7]                       = AssaultChaingunDryFireSound;
		   stateTimeoutValue[7]                = 0.5;
		   stateTransitionOnTimeout[7]         = "NoAmmo";

		   stateName[8]                        = "NoAmmo";
		   stateTransitionOnAmmo[8]            = "Reload";
		   stateSequence[8]                    = "NoAmmo";
		   stateTransitionOnTriggerDown[8]     = "DryFire";

		};

	//**************************************************************
	// Shockwave Gun (Formally Tank Mortar)
	//**************************************************************
		datablock TurretImageData(ShockwaveMortarBarrel) {
		   //shapeFile = "turret_tank_barrelmortar.dts";
		   shapeFile = "weapon_mortar.dts";
		   mountPoint = 2;

		   offset = "0.52 0.8 0.34";
		   //rotation = "1 0 0 0";

		   projectile = ShockwaveGunMortar;
		   projectileType = GrenadeProjectile;

		   usesEnergy = true;
		   useMountEnergy = true;
		   fireEnergy = 35.00; // was 77.00
		   minEnergy = 45.00; // was 77.00
		   useCapacitor = false;

		   // Turret parameters
		   activationMS                        = 4000;
		   deactivateDelayMS                   = 1500;
		   thinkTimeMS                         = 200;
		   degPerSecTheta                      = 360;
		   degPerSecPhi                        = 360;
		   attackRadius                        = 75;

		   // State transitions
		   stateName[0]                        = "Activate";
		   stateTransitionOnNotLoaded[0]       = "Dead";
		   stateTransitionOnLoaded[0]          = "ActivateReady";

		   stateName[1]                        = "ActivateReady";
		   stateSequence[1]                    = "Activate";
		   stateSound[1]                       = AssaultTurretActivateSound;
		   stateTimeoutValue[1]                = 1.0;
		   stateTransitionOnTimeout[1]         = "Ready";
		   stateTransitionOnNotLoaded[1]       = "Deactivate";

		   stateName[2]                        = "Ready";
		   stateTransitionOnNotLoaded[2]       = "Deactivate";
		   stateTransitionOnNoAmmo[2]          = "NoAmmo";
		   stateTransitionOnTriggerDown[2]     = "Fire";

		   stateName[3] = "Fire";
		   stateSequence[3] = "Recoil";
		   stateTransitionOnTimeout[3] = "Reload";
		   stateTimeoutValue[3] = 0.8;
		   stateFire[3] = true;
		   stateRecoil[3] = LightRecoil;
		   stateAllowImageChange[3] = false;
		   stateScript[3] = "onFire";
		   stateSound[3] = MortarFireSound;

		   stateName[4]                        = "Reload";
		   stateSequence[4]                    = "Reload";
		   stateTimeoutValue[4]                = 0.5;
		   stateAllowImageChange[4]            = false;
		   stateTransitionOnTimeout[4]         = "Ready";
		   //stateTransitionOnNoAmmo[4]        = "NoAmmo";
		   stateWaitForTimeout[4]              = true;

		   stateName[5]                        = "Deactivate";
		   stateDirection[5]                   = false;
		   stateSequence[5]                    = "Activate";
		   stateTimeoutValue[5]                = 1.0;
		   stateTransitionOnLoaded[5]          = "ActivateReady";
		   stateTransitionOnTimeout[5]         = "Dead";

		   stateName[6]                        = "Dead";
		   stateTransitionOnLoaded[6]          = "ActivateReady";
		   stateTransitionOnTriggerDown[6]     = "DryFire";

		   stateName[7]                        = "DryFire";
		   stateSound[7]                       = AssaultMortarDryFireSound;
		   stateTimeoutValue[7]                = 1.0;
		   stateTransitionOnTimeout[7]         = "NoAmmo";

		   stateName[8]                        = "NoAmmo";
		   stateSequence[8]                    = "NoAmmo";
		   stateTransitionOnAmmo[8]            = "Reload";
		   stateTransitionOnTriggerDown[8]     = "DryFire";
		};

		datablock TurretImageData(AssaultTurretParam) {
		   mountPoint = 2;
		   shapeFile = "turret_muzzlepoint.dts";

		   projectile = AssaultChaingunBullet;
		   projectileType = TracerProjectile;

		   useCapacitor = true;
		   usesEnergy = true;

		   // Turret parameters
		   activationMS      = 1000;
		   deactivateDelayMS = 1500;
		   thinkTimeMS       = 200;
		   degPerSecTheta    = 500;
		   degPerSecPhi      = 500;
		   
		   attackRadius      = 75;
		};              



	//**************************************************************
	// shrike blasters
	//**************************************************************
		datablock ShapeBaseImageData(ScoutChaingunPairImage) {
		   className = WeaponImage;
		   shapeFile = "weapon_energy_vehicle.dts";
		   item      = Chaingun;
		   ammo   = ChaingunAmmo;
		   projectile = ScoutChaingunBullet;
		   projectileType = TracerProjectile;
		   mountPoint = 10;

		//**original**   offset = ".73 0 0";
		//   offset = "1.93 -0.52 0.044";
		   offset = "0.52 0.8 0.27";

		   projectileSpread = 1.0 / 1000.0;
		   
		   usesEnergy = true;
		   useMountEnergy = true;
		   // DAVEG -- balancing numbers below!
		   minEnergy = 15;
		   fireEnergy = 7;
		   fireTimeout = 125;

		   //--------------------------------------
		   stateName[0]                = "Activate";
		   stateSequence[0]            = "Activate";
		   stateAllowImageChange[0]    = false;
		   stateTimeoutValue[0]        = 0.05;
		   stateTransitionOnTimeout[0] = "Ready";
		   stateTransitionOnNoAmmo[0]  = "NoAmmo";
		   //--------------------------------------
		   stateName[1]       = "Ready";
		   stateSpinThread[1] = Stop;
		   stateTransitionOnTriggerDown[1] = "Spinup";
		   stateTransitionOnNoAmmo[1]      = "NoAmmo";
		   //--------------------------------------
		   stateName[2]               = "NoAmmo";
		   stateTransitionOnAmmo[2]   = "Ready";
		   stateSpinThread[2]         = Stop;
		   stateTransitionOnTriggerDown[2] = "DryFire";
		   //--------------------------------------
		   stateName[3]         = "Spinup";
		   stateSpinThread[3]   = SpinUp;
		   stateTimeoutValue[3]          = 0.01;
		   stateWaitForTimeout[3]        = false;
		   stateTransitionOnTimeout[3]   = "Fire";
		   stateTransitionOnTriggerUp[3] = "Spindown";
		   //--------------------------------------
		   stateName[4]             = "Fire";
		   stateSpinThread[4]       = FullSpeed;
		   stateRecoil[4]           = LightRecoil;
		   stateAllowImageChange[4] = false;
		   stateScript[4]           = "onFire";
		   stateFire[4]             = true;
		   stateSound[4]            = ShrikeBlasterFire;
		   // IMPORTANT! The stateTimeoutValue below has been replaced by fireTimeOut
		   // above.
		   stateTimeoutValue[4]          = 0.25;
		   stateTransitionOnTimeout[4]   = "checkState";
		   //--------------------------------------
		   stateName[5]       = "Spindown";
		   stateSpinThread[5] = SpinDown;
		   stateTimeoutValue[5]            = 0.01;
		   stateWaitForTimeout[5]          = false;
		   stateTransitionOnTimeout[5]     = "Ready";
		   stateTransitionOnTriggerDown[5] = "Spinup";
		   //--------------------------------------
		   stateName[6]       = "EmptySpindown";
		//   stateSound[6]      = ChaingunSpindownSound;
		   stateSpinThread[6] = SpinDown;
		   stateTransitionOnAmmo[6]   = "Ready";
		   stateTimeoutValue[6]        = 0.01;
		   stateTransitionOnTimeout[6] = "NoAmmo";
		   //--------------------------------------
		   stateName[7]       = "DryFire";
		   stateSound[7]      = ShrikeBlasterDryFireSound;
		   stateTransitionOnTriggerUp[7] = "NoAmmo";
		   stateTimeoutValue[7]        = 0.25;
		   stateTransitionOnTimeout[7] = "NoAmmo";

		   stateName[8] = "checkState";
		   stateTransitionOnTriggerUp[8] = "Spindown";
		   stateTransitionOnNoAmmo[8]    = "EmptySpindown";
		   stateTimeoutValue[8]          = 0.01;
		   stateTransitionOnTimeout[8]   = "ready";
		};

		datablock ShapeBaseImageData(ScoutChaingunImage) : ScoutChaingunPairImage {
		   //**original**   offset = "-.73 0 0";
		   //offset = "-1.93 -0.52 0.044"; // shrike offset
		   offset = "-0.52 0.8 0.27";

		   stateScript[3]           = "onTriggerDown";
		   stateScript[5]           = "onTriggerUp";
		   stateScript[6]           = "onTriggerUp";
		};

		datablock ShapeBaseImageData(ScoutChaingunParam) {
		   mountPoint = 2;
		   shapeFile = "turret_muzzlepoint.dts";

		   projectile = ScoutChaingunBullet;
		   projectileType = TracerProjectile;
		}; 


	//**************************************************************
	// Bomber gun 
	//**************************************************************
		datablock TurretImageData(BomberMortarBarrel) {
		   //shapeFile = "turret_tank_barrelmortar.dts";
		   shapeFile = "weapon_mortar.dts";
		   mountPoint = 2;

		   offset = "0.9 -1.3 -0.1";
//		   rotation = "1 0 0 180";

		   projectile = BomberGunBomb;
		   projectileType = GrenadeProjectile; // this is so they have a stalltime.. they won't blow up automaticly

		   usesEnergy = true;
		   useMountEnergy = true;
		   fireEnergy = 40.00; // was 77.00
		   minEnergy = 55.00; // was 77.00
		   useCapacitor = false;

		   // Turret parameters
		   activationMS                        = 4000;
		   deactivateDelayMS                   = 300;
		   thinkTimeMS                         = 100;
		   degPerSecTheta                      = 360;
		   degPerSecPhi                        = 360;
		   attackRadius                        = 75;

		   // State transitions
		   stateName[0]                        = "Activate";
		   stateTransitionOnNotLoaded[0]       = "Dead";
		   stateTransitionOnLoaded[0]          = "ActivateReady";

		   stateName[1]                        = "ActivateReady";
		   stateSequence[1]                    = "Activate";
		   stateSound[1]                       = AssaultTurretActivateSound;
		   stateTimeoutValue[1]                = 0.5; // was 1.0
		   stateTransitionOnTimeout[1]         = "Ready";
		   stateTransitionOnNotLoaded[1]       = "Deactivate";

		   stateName[2]                        = "Ready";
		   stateTransitionOnNotLoaded[2]       = "Deactivate";
		   stateTransitionOnNoAmmo[2]          = "NoAmmo";
		   stateTransitionOnTriggerDown[2]     = "Fire";

		   stateName[3]				    = "Fire";
		   stateSequence[3]				    = "Recoil";
		   stateTransitionOnTimeout[3]	    = "Reload";
		   stateTimeoutValue[3]			    = 0.5; // was 0.8
		   stateFire[3]				    = true;
		   stateRecoil[3]				    = LightRecoil;
		   stateAllowImageChange[3]		    = false;
		   stateScript[3]				    = "onFire";
		   //stateSound[3]				    = MortarFireSound;
		   stateSound[3]                       = AssaultMortarFireSound;

		   stateName[4]                        = "Reload";
		   stateSequence[4]                    = "Reload";
		   stateTimeoutValue[4]                = 0.5;
		   stateAllowImageChange[4]            = false;
		   stateTransitionOnTimeout[4]         = "Ready";
		   //stateTransitionOnNoAmmo[4]        = "NoAmmo";
		   stateWaitForTimeout[4]              = true;

		   stateName[5]                        = "Deactivate";
		   stateDirection[5]                   = false;
		   stateSequence[5]                    = "Activate";
		   stateTimeoutValue[5]                = 0.5; // was 1.0
		   stateTransitionOnLoaded[5]          = "ActivateReady";
		   stateTransitionOnTimeout[5]         = "Dead";

		   stateName[6]                        = "Dead";
		   stateTransitionOnLoaded[6]          = "ActivateReady";
		   stateTransitionOnTriggerDown[6]     = "DryFire";

		   stateName[7]                        = "DryFire";
		   stateSound[7]                       = AssaultMortarDryFireSound;
		   stateTimeoutValue[7]                = 0.5; // was 1.0
		   stateTransitionOnTimeout[7]         = "NoAmmo";

		   stateName[8]                        = "NoAmmo";
		   stateSequence[8]                    = "NoAmmo";
		   stateTransitionOnAmmo[8]            = "Reload";
		   stateTransitionOnTriggerDown[8]     = "DryFire";
		};

	//**************************************************************
	// SmokeScreen gun 
	//**************************************************************
		datablock TurretImageData(SmokeScreenGunBarrel) {
		   shapeFile = "turret_tank_barrelmortar.dts";
		   //shapeFile = "weapon_mortar.dts";
		   mountPoint = 2;

		   offset = "-0.02 -0.9 -0.2";
//		   rotation = "1 0 0 180";

		   projectile = SmokeScreenGunMortar;
		   projectileType = GrenadeProjectile; // this is so they have a stalltime.. they won't blow up automaticly

		   usesEnergy = true;
		   useMountEnergy = true;
		   fireEnergy = 20.00; // was 77.00
		   minEnergy = 40.00; // was 77.00
		   useCapacitor = false;

		   // Turret parameters
		   activationMS                        = 4000;
		   deactivateDelayMS                   = 1500;
		   thinkTimeMS                         = 200;
		   degPerSecTheta                      = 360;
		   degPerSecPhi                        = 360;
		   attackRadius                        = 75;

		   // State transitions
		   stateName[0]                        = "Activate";
		   stateTransitionOnNotLoaded[0]       = "Dead";
		   stateTransitionOnLoaded[0]          = "ActivateReady";

		   stateName[1]                        = "ActivateReady";
		   stateSequence[1]                    = "Activate";
		   stateSound[1]                       = AssaultTurretActivateSound;
		   stateTimeoutValue[1]                = 0.25; // was 1.0
		   stateTransitionOnTimeout[1]         = "Ready";
		   stateTransitionOnNotLoaded[1]       = "Deactivate";

		   stateName[2]                        = "Ready";
		   stateTransitionOnNotLoaded[2]       = "Deactivate";
		   stateTransitionOnNoAmmo[2]          = "NoAmmo";
		   stateTransitionOnTriggerDown[2]     = "Fire";

		   stateName[3]                        = "Fire";
		   stateSequence[3]                    = "Fire";
		   stateTransitionOnTimeout[3]         = "Reload";
		   stateTimeoutValue[3]                = 0.25;
		   stateFire[3]                        = true;
		   stateRecoil[3]                      = LightRecoil;
		   stateAllowImageChange[3]            = false;
		   stateSound[3]                       = AssaultMortarFireSound;
		   stateScript[3]                      = "onFire";

		   stateName[4]                        = "Reload";
		   stateSequence[4]                    = "Reload";
		   stateTimeoutValue[4]                = 0.25;
		   stateAllowImageChange[4]            = false;
		   stateTransitionOnTimeout[4]         = "Ready";
		   //stateTransitionOnNoAmmo[4]        = "NoAmmo";
		   stateWaitForTimeout[4]              = true;

		   stateName[5]                        = "Deactivate";
		   stateDirection[5]                   = false;
		   stateSequence[5]                    = "Activate";
		   stateTimeoutValue[5]                = 0.25; // was 1.0
		   stateTransitionOnLoaded[5]          = "ActivateReady";
		   stateTransitionOnTimeout[5]         = "Dead";

		   stateName[6]                        = "Dead";
		   stateTransitionOnLoaded[6]          = "ActivateReady";
		   stateTransitionOnTriggerDown[6]     = "DryFire";

		   stateName[7]                        = "DryFire";
		   stateSound[7]                       = AssaultMortarDryFireSound;
		   stateTimeoutValue[7]                = 0.25; // was 1.0
		   stateTransitionOnTimeout[7]         = "NoAmmo";

		   stateName[8]                        = "NoAmmo";
		   stateSequence[8]                    = "NoAmmo";
		   stateTransitionOnAmmo[8]            = "Reload";
		   stateTransitionOnTriggerDown[8]     = "DryFire";
		};

// BLOWER - 1.1
		datablock TurretImageData(Blower) { // this is false We trick it :> - MeBaD
		   shapefile = "blower.dts";
		   mountPoint = 1;

		   offset = "0 -0.3 0.51";

		// oh yes .. I hacked the shit out of the plasma bullet :)
		   projectile = PlasmaBolt;
		   projectileType = LinearFlareProjectile;

		   usesEnergy = true;
		   useMountEnergy = true;
  		   fireEnergy = 0.001; // I'm such a cheater :>
		   minEnergy = 10.00;
		   useCapacitor = false;

		   // Turret parameters
		   activationMS                        = 32;
		   deactivateDelayMS                   = 32; // lowest it will go! :(
		   thinkTimeMS                         = 32;
		   degPerSecTheta                      = 360;
		   degPerSecPhi                        = 360;
		   //attackRadius                        = 75;

		   // State transitions
		   stateName[0]                        = "Activate";
		   stateTransitionOnNotLoaded[0]       = "Dead";
		   stateTransitionOnLoaded[0]          = "ActivateReady";

		   stateName[1]                        = "ActivateReady";
		   stateSequence[1]                    = "Activate";
//		   stateSound[1]                       = AssaultTurretActivateSound;
		   stateTimeoutValue[1]                = 0.25; // was 1.0
		   stateTransitionOnTimeout[1]         = "Ready";
		   stateTransitionOnNotLoaded[1]       = "Deactivate";

		   stateName[2]                        = "Ready";
		   stateTransitionOnNotLoaded[2]       = "Deactivate";
		   stateTransitionOnNoAmmo[2]          = "NoAmmo";
		   stateTransitionOnTriggerDown[2]     = "Fire";

		   stateName[3]			       = "Fire";
		   stateSequence[3]		       = "Fire";
		   stateSequenceRandomFlash[3]	       = true;
		   stateSpinThread[3]		       = FullSpeed;
		   stateSound[3]	               = SatchelChargeActivateSound;
		   //stateRecoil[3]		       = LightRecoil;
		   stateAllowImageChange[3]	       = false;
		   stateScript[3]		       = "onFire";
		   stateFire[3]			       = true;
		   stateEjectShell[3]		       = true;
		   stateTimeoutValue[3]		       = 0.15;
		   stateTransitionOnTimeout[3]	       = "Fire";
		   stateTransitionOnTriggerUp[3]       = "Reload";
		   stateTransitionOnNoAmmo[3]	       = "Reload";

		   stateName[4]                        = "Reload";
		   stateSequence[4]                    = "Ready";
		   stateTimeoutValue[4]                = 1.0;
		   stateAllowImageChange[4]            = false;
		   stateTransitionOnTimeout[4]         = "Ready";
		   //stateTransitionOnNoAmmo[4]        = "NoAmmo";
		   stateWaitForTimeout[4]              = false;

		   stateName[5]                        = "Deactivate";
		   stateDirection[5]                   = false;
		   stateSequence[5]                    = "Activate";
		   stateTimeoutValue[5]                = 0.25; // was 1.0
		   stateTransitionOnLoaded[5]          = "ActivateReady";
		   stateTransitionOnTimeout[5]         = "Dead";

		   stateName[6]                        = "Dead";
		   stateTransitionOnLoaded[6]          = "ActivateReady";
		   stateTransitionOnTriggerDown[6]     = "DryFire";

		   stateName[7]                        = "DryFire";
		   stateSound[7]                       = AssaultMortarDryFireSound;
		   stateTimeoutValue[7]                = 0.25; // was 1.0
		   stateTransitionOnTimeout[7]         = "NoAmmo";

		   stateName[8]                        = "NoAmmo";
		   stateSequence[8]                    = "NoAmmo";
		   stateTransitionOnAmmo[8]            = "Reload";
		   stateTransitionOnTriggerDown[8]     = "DryFire";
		};

//***************************************************************************************************
// Grav Blaster functions - this is ghey .. but has to be done to get both to fire :(
//***************************************************************************************************
	function MeBaDGravVehicle::onTrigger(%data, %obj, %trigger, %state) {
		ScoutVehicle::onTrigger(%data, %obj, %trigger, %state);
	}
	function OracleVehicle::onTrigger(%data, %obj, %trigger, %state) {
		ScoutVehicle::onTrigger(%data, %obj, %trigger, %state);
	}
	function ScoutVehicle::onTrigger(%data, %obj, %trigger, %state) {
	   // data = ScoutFlyer datablock
	   // obj = ScoutFlyer object number
	   // trigger = 0 for "fire", 1 for "jump", 3 for "thrust"
	   // state = 1 for firing, 0 for not firing

		if (%trigger == 0) {
			switch (%state) {
				case 0:
					%obj.fireWeapon = false;
					%obj.setImageTrigger(2, false);
					%obj.setImageTrigger(3, false);
				case 1:
					%obj.fireWeapon = true;
					if(%obj.nextWeaponFire == 2) {
						%obj.setImageTrigger(2, true);
						%obj.setImageTrigger(3, false);
					} else {
						%obj.setImageTrigger(2, false);
						%obj.setImageTrigger(3, true);
					}
			}
		}
		if (%trigger == 0) { // was right mouse .. 3
			//error("Blowing called");
		        if (%state) {
				%obj.setImageTrigger(4, true);
				BlowerBlow(%obj, %obj.lastPilot);
		        } else {
				%obj.setImageTrigger(4, false);
				cancel(%obj.lastPilot.blowerschedule);
			}
		}
		if (%trigger == 1) {
			%obj.setImageTrigger(4, false); // this would cause a nasty bug without this
			cancel(%obj.lastPilot.blowerschedule);
		}		
		// Added blower FX Version 1.1
	}

	//onBlowing - blower pushes .. while jacking up your heat
	function BlowerBlow(%obj, %player) {
		if ((isObject(%obj.lastPilot)) && (%player.invMotionSensorDeployable)) {

			%heatlvl = %player.getDamageFlash();
//			error("Blower boost called: " @ %obj @ " - Player: " @ %player @ " HEAT : " @ %heatlvl);

			if (%heatlvl < 0.8) {
				%player.setDamageFlash((%heatlvl + 0.3));
				%obj.applyImpulse(%obj.getTransform(), VectorScale(%player.getMuzzleVector(0), 10000));
				%obj.lastPilot.blowerschedule = schedule (300, 0, "BlowerBlow", %obj, %obj.lastPilot);				
			} else {
				%obj.blowup();
				%obj.schedule(2000, "delete");
				serverPlay3D(MortarExplosionSound, %player.position);

					new ParticleEmissionDummy(TriggerHappy) {
						position = %player.position;
						rotation = "1 0 0 0";
						scale = "1 1 1";
						dataBlock = "defaultEmissionDummy";
						emitter = "VehicleBombExplosionEmitter";
						velocity = "0";
					};

					TriggerHappy.schedule(500, "delete");

				// Emmit a cloud! -> VehicleBombExplosionEmitter

				// fuck damage type code flimzy shit
				%player.scriptKill($DamageType::Default);
				messageall(0, '%1 went up with a blower of glory!', %player.client.namebase);

				%player.blowup();
			}
		}
	}