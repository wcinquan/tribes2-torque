//-----------------------------------------------------------------------------
// Wave Profile Lists
//
new WaveProfile(calmSea)
{
};

new WaveProfile(chop)
{
};

new WaveProfile(bubblyLava)
{
};

new WaveProfile(coolingLava)
{
};

new WaveProfile(quicksand)
{
};