////////////////////////////////////////////////////////////////////////////////
/// -MAP SUPPORT PACKAGE- //////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/// -By Founder and ZOD- ///////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

package mapGameOverloads
{
   function loadMission( %missionName, %missionType, %firstMission )
   {
      Parent::loadMission( %missionName, %missionType, %firstMission );
      if(isPackage(%missionName))
      {
         activatePackage(%missionName);
         eval(%missionName @ "::preLoad(%firstMission);");
      }
   }

   function DefaultGame::missionLoadDone(%game)
   {
      Parent::missionLoadDone(%game);
      if(isPackage($MissionName))
      {
         activatePackage($MissionName);
         eval($MissionName @ "::InitMap();");
      }    
   }

   function DefaultGame::gameOver( %game )
   {
      Parent::gameOver( %game );
      echo("<>>>>> MAP SUPPORT CLEAN UP <<<<<>");
      if(isPackage($MissionName))
           eval($MissionName @ "::DeactivateMap();");

      if($Map::OldSpiderClampMax $="")
         $Map::OldSpiderClampMax = 10;
      if($Map::OldLandSpikeMax $="")
         $Map::OldLandSpikeMax = 10;
      if($Map::OldSpiderClampMin $="")
         $Map::OldSpiderClampMin = 4;
      if($Map::OldLandSpikeMin $="")
         $Map::OldLandSpikeMin = 4;
      if($Map::OldVehicleRespawn $="")
         $Map::OldVehicleRespawn = 15000;
      if($Map::OldWildcatMax $="")
         $Map::OldWildcatMax = 4;
      if($Map::OldTankMax $="")
         $Map::OldTankMax = 3;
      if($Map::OldMpbMax $="")
         $Map::OldMpbMax = 1;
      if($Map::OldScoutMax $="")
         $Map::OldScoutMax = 4;
      if($Map::OldBomberMax $="")
         $Map::OldBomberMax = 2;
      if($Map::OldHapcMax $="")
         $Map::OldHapcMax = 2;

      $TeamDeployableMax[TurretIndoorDeployable] = $Map::OldSpiderClampMax;
      $TeamDeployableMax[TurretOutdoorDeployable] = $Map::OldLandSpikeMax;
      $TeamDeployableMin[TurretIndoorDeployable] = $Map::OldSpiderClampMin;
      $TeamDeployableMin[TurretOutdoorDeployable] = $Map::OldLandSpikeMin;
      $VehicleRespawnTime = $Map::OldVehicleRespawn;
      $Vehiclemax[ScoutVehicle] = $Map::OldWildcatMax;
      $VehicleMax[AssaultVehicle] = $Map::OldTankMax;
      $VehicleMax[MobileBaseVehicle] = $Map::OldMpbMax;
      $VehicleMax[ScoutFlyer] = $Map::OldScoutMax;
      $VehicleMax[BomberFlyer] = $Map::OldBomberMax;
      $VehicleMax[HAPCFlyer] = $Map::OldHapcMax;

//      if(isPackage($MissionName))
//           deactivatepackage($MissionName);
   }
   
   function DestroyServer() // stop bad loop on soft server restart
   {
   // $MapScriptsLoaded = "";
   echo("DestroyServer:mapGame.cs Zapped");
   Parent::DestroyServer();
   }
   
   
};
if($Host::MapScript $= "" || $Host::MapScript == 1)
     activatePackage(mapGameOverloads);

////////////////////////////////////////////////////////////////////////////////
