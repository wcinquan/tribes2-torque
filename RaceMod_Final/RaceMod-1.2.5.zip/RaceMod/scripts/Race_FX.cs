//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// Drag Tree Emitters
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
datablock ParticleData(DragTreeYellowParticle)
{
    dragCoefficient = 0;
    gravityCoefficient = 0;
    windCoefficient = 1;
    inheritedVelFactor = 0.2;
    constantAcceleration = 0;
    lifetimeMS = 1000;
    lifetimeVarianceMS = 100;
    useInvAlpha = 0;
    spinRandomMin = -60;
    spinRandomMax = 60;
    textureName = "particleTest.png";
    times[0] = 0;
    times[1] = 0.99;
    times[2] = 1;
    colors[0] = "1.000000 1.000000 0.000000 1.000000";
    colors[1] = "1.000000 1.000000 0.000000 0.500000";
    colors[2] = "0.000000 0.000000 0.000000 0.000000";
    sizes[0] = 1.377419;
    sizes[1] = 1.546774;
    sizes[2] = 1.377419;
};

datablock ParticleEmitterData(DragTreeYellowEmitter)
{
    ejectionPeriodMS = 7;
    periodVarianceMS = 1;
    ejectionVelocity = 1;
    velocityVariance = 0.2;
    ejectionOffset =   0;
    thetaMin = 0;
    thetaMax = 40;
    phiReferenceVel = 0;
    phiVariance = 360;
    overrideAdvances = 0;
    orientParticles= 0;
    orientOnVelocity = 1;
    particles = "DragTreeYellowParticle";
};

datablock ParticleData(DragTreeRedParticle)
{
    dragCoefficient = 0;
    gravityCoefficient = 0;
    windCoefficient = 1;
    inheritedVelFactor = 0.2;
    constantAcceleration = 0;
    lifetimeMS = 1000;
    lifetimeVarianceMS = 100;
    useInvAlpha = 0;
    spinRandomMin = -60;
    spinRandomMax = 60;
    textureName = "particleTest.png";
    times[0] = 0;
    times[1] = 0.99;
    times[2] = 1;
    colors[0] = "1.000000 0.000000 nan 1.000000";
    colors[1] = "1.000000 0.000000 0.000000 1.000000";
    colors[2] = "1.000000 0.000000 0.000000 0.500000";
    sizes[0] = 1.377419;
    sizes[1] = 1.546774;
    sizes[2] = 1.377419;
};

datablock ParticleEmitterData(DragTreeRedEmitter)
{
    ejectionPeriodMS = 7;
    periodVarianceMS = 1;
    ejectionVelocity = 1;
    velocityVariance = 0.2;
    ejectionOffset =   0;
    thetaMin = 0;
    thetaMax = 40;
    phiReferenceVel = 0;
    phiVariance = 360;
    overrideAdvances = 0;
    orientParticles= 0;
    orientOnVelocity = 1;
    particles = "DragTreeRedParticle";
};


datablock ParticleData(DragTreeGreenParticle)
{
    dragCoefficient = 0;
    gravityCoefficient = 0;
    windCoefficient = 1;
    inheritedVelFactor = 0.2;
    constantAcceleration = 0;
    lifetimeMS = 2500;
    lifetimeVarianceMS = 250;
    useInvAlpha = 0;
    spinRandomMin = -60;
    spinRandomMax = 60;
    textureName = "particleTest.png";
    times[0] = 0;
    times[1] = 0.01;
    times[2] = 1;
    colors[0] = "0.000000 1.000000 0.000000 1.000000";
    colors[1] = "0.000000 1.000000 0.000000 0.524194";
    colors[2] = "0.000000 0.000000 0.000000 0.000000";
    sizes[0] = 1.977419;
    sizes[1] = 2.146774;
    sizes[2] = 1.977419;
};

datablock ParticleEmitterData(DragTreeGreenEmitter)
{
    ejectionPeriodMS = 7;
    periodVarianceMS = 1;
    ejectionVelocity = 1;
    velocityVariance = 0.2;
    ejectionOffset =   0;
    thetaMin = 0;
    thetaMax = 40;
    phiReferenceVel = 0;
    phiVariance = 360;
    overrideAdvances = 0;
    orientParticles= 0;
    orientOnVelocity = 1;
    particles = "DragTreeGreenParticle";
};

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
// Nova Cycle Emitter - MeBaD
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

datablock ParticleData(NovaGravParticle) {
    dragCoefficient = 0;
    gravityCoefficient = -0.01;
    windCoefficient = 0;
    inheritedVelFactor = 0;
    constantAcceleration = 0;
    lifetimeMS = 790;
    lifetimeVarianceMS = 0;
    useInvAlpha = 0;
    spinRandomMin = 0;
    spinRandomMax = 750;
    textureName = "particleTest";
    times[0] = 0;
    times[1] = 0.85;
    times[2] = 1;
    colors[0] = "1.000000 0.750000 0.000000 0.500000";
    colors[1] = "1.000000 0.000000 0.000000 1.000000";
    colors[2] = "1.000000 1.000000 1.000000 1.000000";
    sizes[0] = 1.076378;
    sizes[1] = 0.733871;
    sizes[2] = 0.282258;
};

datablock ParticleEmitterData(NovaGravEmitter) {
    ejectionPeriodMS = 1;
    periodVarianceMS = 0;
    ejectionVelocity = 6.80645;
    velocityVariance = 6.80645;
    ejectionOffset =   0;
    thetaMin = 0;
    thetaMax = 0;
    phiReferenceVel = 360;
    phiVariance = 0;
    overrideAdvances = 0;
    orientParticles= 0;
    orientOnVelocity = 1;
    particles = "NovaGravParticle";
};

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
// Oracle Cycle Emitter - MeBaD
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

datablock ParticleData(OracleGravParticle) {
    dragCoefficient = 0;
    gravityCoefficient = -0.01;
    windCoefficient = 0;
    inheritedVelFactor = 0;
    constantAcceleration = 0;
    lifetimeMS = 790;
    lifetimeVarianceMS = 0;
    useInvAlpha = 0;
    spinRandomMin = 0;
    spinRandomMax = 750;
    textureName = "particleTest";
    times[0] = 0;
    times[1] = 0.85;
    times[2] = 1;
    colors[0] = "0.000000 1.000000 0.000000 0.500000";
    colors[1] = "0.000000 0.000000 1.000000 1.000000";
    colors[2] = "1.000000 1.000000 1.000000 1.000000";
    sizes[0] = 1.076378;
    sizes[1] = 0.733871;
    sizes[2] = 0.282258;
};

datablock ParticleEmitterData(OracleGravEmitter) {
    ejectionPeriodMS = 1;
    periodVarianceMS = 0;
    ejectionVelocity = 6.80645;
    velocityVariance = 6.80645;
    ejectionOffset =   0;
    thetaMin = 0;
    thetaMax = 0;
    phiReferenceVel = 360;
    phiVariance = 0;
    overrideAdvances = 0;
    orientParticles= 0;
    orientOnVelocity = 1;
    particles = "OracleGravParticle";
};

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
// America Cycle Emitter - MeBaD
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

datablock ParticleData(AmeriGravParticle) {
    dragCoefficient = 0;
    gravityCoefficient = -0.01;
    windCoefficient = 0;
    inheritedVelFactor = 0;
    constantAcceleration = 0;
    lifetimeMS = 790;
    lifetimeVarianceMS = 0;
    useInvAlpha = 0;
    spinRandomMin = 0;
    spinRandomMax = 750;
    textureName = "particleTest";
    times[0] = 0;
    times[1] = 0.50;
    times[2] = 1;
    colors[0] = "1.000000 0.000000 0.000000 1.000000";
    colors[1] = "1.000000 1.000000 1.000000 0.500000";
    colors[2] = "0.000000 0.000000 1.000000 1.000000";
    sizes[0] = 1.076378;
    sizes[1] = 0.733871;
    sizes[2] = 0.582258;
};

datablock ParticleEmitterData(AmeriGravEmitter) {
    ejectionPeriodMS = 1;
    periodVarianceMS = 0;
    ejectionVelocity = 6.80645;
    velocityVariance = 6.80645;
    ejectionOffset =   0;
    thetaMin = 0;
    thetaMax = 0;
    phiReferenceVel = 360;
    phiVariance = 0;
    overrideAdvances = 0;
    orientParticles= 0;
    orientOnVelocity = 1;
    particles = "AmeriGravParticle";
};

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
// New Tank Emitter - MeBaD
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

datablock ParticleData(MeBaDTankParticle) {
    dragCoefficient = 0;
    gravityCoefficient = -0.01;
    windCoefficient = 0;
    inheritedVelFactor = 0;
    constantAcceleration = 0;
    lifetimeMS = 887;
    lifetimeVarianceMS = 0;
    useInvAlpha = 0;
    spinRandomMin = 0;
    spinRandomMax = 750;
    textureName = "flaremod";
    times[0] = 0;
    times[1] = 0.85;
    times[2] = 1;
    colors[0] = "1.000000 0.000000 0.000000 1.000000";
    colors[1] = "1.000000 0.104000 0.000000 1.000000";
    colors[2] = "1.000000 1.000000 1.000000 0.000000";
    sizes[0] = 2.54032;
    sizes[1] = 0.508065;
    sizes[2] = 0.508065;
};

datablock ParticleEmitterData(MeBaDTankEmitter) {
    ejectionPeriodMS = 1;
    periodVarianceMS = 0;
    ejectionVelocity = 6.80645;
    velocityVariance = 6.80645;
    ejectionOffset =   0;
    thetaMin = 0;
    thetaMax = 0;
    phiReferenceVel = 360;
    phiVariance = 0;
    overrideAdvances = 0;
    orientParticles= 0;
    orientOnVelocity = 1;
    particles = "MeBaDTankParticle";
};

datablock ParticleData(UrbanTankParticle) {
    dragCoefficient = 0;
    gravityCoefficient = -0.01;
    windCoefficient = 0;
    inheritedVelFactor = 0;
    constantAcceleration = 0;
    lifetimeMS = 887;
    lifetimeVarianceMS = 0;
    useInvAlpha = 0;
    spinRandomMin = 0;
    spinRandomMax = 750;
    textureName = "flaremod";
    times[0] = 0;
    times[1] = 0.85;
    times[2] = 1;
    colors[0] = "0.000000 1.000000 0.000000 1.000000";
    colors[1] = "1.000000 0.104000 0.000000 1.000000";
    colors[2] = "1.000000 1.000000 1.000000 0.000000";
    sizes[0] = 2.54032;
    sizes[1] = 0.508065;
    sizes[2] = 0.508065;
};

datablock ParticleEmitterData(UrbanTankEmitter) {
    ejectionPeriodMS = 1;
    periodVarianceMS = 0;
    ejectionVelocity = 6.80645;
    velocityVariance = 6.80645;
    ejectionOffset =   0;
    thetaMin = 0;
    thetaMax = 0;
    phiReferenceVel = 360;
    phiVariance = 0;
    overrideAdvances = 0;
    orientParticles= 0;
    orientOnVelocity = 1;
    particles = "UrbanTankParticle";
};

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
// NOS Bottle - Byte
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
datablock ShapeBaseImageData(NOSBottle) { // this is false We trick it :> - MeBaD
   shapefile = "nosbottle.dts";
   mountPoint = 2;

   offset = "0.45 -1.23 0.41";
};

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// Map Emitters
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
datablock ParticleData(h20fallParticle) {
    dragCoefficient = 0;
    gravityCoefficient = 0.1;
    windCoefficient = 35;
    inheritedVelFactor = 0.814516;
    constantAcceleration = 0;
    lifetimeMS = 10000;
    lifetimeVarianceMS = 750;
    useInvAlpha = 0;
    spinRandomMin = -138.71;
    spinRandomMax = 550.403;
    textureName = "special/Smoke/smoke_008.png";
    times[0] = 0;
    times[1] = 0.169355;
    times[2] = 1;
    colors[0] = "0.000000 0.000000 1.000000 1.000000";
    colors[1] = "0.307087 0.568000 1.000000 0.483871";
    colors[2] = "0.000000 0.472000 1.000000 0.000000";
    sizes[0] = 6;
    sizes[1] = 4.5;
    sizes[2] = 2;
};

datablock ParticleEmitterData(h20fallEmitter) {
    ejectionPeriodMS = 1;
    periodVarianceMS = 0;
    ejectionVelocity = 10;
    velocityVariance = 5;
    ejectionOffset =   0;
    thetaMin = 0;
    thetaMax = 90;
    phiReferenceVel = 360;
    phiVariance = 0;
    overrideAdvances = 0;
    orientParticles= 0;
    orientOnVelocity = 1;
    particles = "h20fallParticle";
};