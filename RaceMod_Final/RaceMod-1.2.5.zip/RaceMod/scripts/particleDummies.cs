//--------------------------------------------------------------------------
// 
// 
// 
//--------------------------------------------------------------------------

datablock ParticleEmissionDummyData(defaultEmissionDummy)
{
   timeMultiple = 1.0;
};

datablock ParticleEmissionDummyData(halftimeEmissionDummy)
{
   timeMultiple = 0.5;
};

datablock ParticleEmissionDummyData(doubleTimeEmissionDummy)
{
   timeMultiple = 2.0;
};

