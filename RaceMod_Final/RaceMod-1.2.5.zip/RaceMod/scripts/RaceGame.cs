// DisplayName = Race

$RaceModVersion = "Version: 1.2.5 OFFICAL (DEV) RELEASE";

//--- GAME RULES BEGIN ---
//<color:00FF00>RaceMod: Version 1.2.5 OFFICAL DEV (<color:FFFF00>NoS|<color:00FF00>) RELEASE - Coder: MeBaD
//<color:0055FF>http://bombshelter.servebeer.com/files/tribes2/RaceMod_MapsV7.5.vl2 - REQUIRED Clientside Mappack
//<color:FF0000>***<color:00FFFF>Drag tree = direction of the race<color:FF0000>***
//<color:FFFF00>NOS Boost = Pack Key... <color:00FFFF>use it wisely :)
//<color:FF0000>MeBaD Kart Mode - Weapons/Upgrades in loadout screen
//<color:00FFFF>Scoring system: 10pts per gate, 100 1st, 75 2nd, 50 3rd <color:FFFF00>(+bonus)
//<color:00FF00>Contact - irc.dynamix.com - Channel #t2++
//<color:00FFFF>http://bombshelter.servebeer.com/?Page=ProPack - Home of RaceMod and the imfamous ProPack
//--- GAME RULES END ---

//=-=-=-=-=-=-=-=
//	RaceGame 
//=-=-=-=-=-=-=-=

$DisableRaceTanks = true; // tanks disabled by default (ver 1.1)

package RaceGame {

	function RaceGame::AIinit() {
		// Bots for a reason!
	}

	function VehicleHud::updateHud( %obj, %client, %tag ) {	//from serverVehicleHud.cs
		%station = %client.player.station;
		%team = %client.getSensorGroup();

		// Have all the vehicles in the mod on no matter what :)
		%station.vehicle[MeBaDGravVehicle] = true;
		%station.vehicle[scoutVehicle] = true;
		%station.vehicle[OracleVehicle] = true;
		%station.vehicle[MeBaDTankVehicle] = true;
		%station.vehicle[AssaultVehicle] = true;
		%station.vehicle[mobileBaseVehicle] = true;

		%count = 0;
	     messageClient( %client, 'SetLineHud', "", %tag, %count, "Ameri Cycle", "", ScoutVehicle, $VehicleMax[ScoutVehicle] - $VehicleTotalCount[%team, ScoutVehicle] );
		     %count++;
		messageClient( %client, 'SetLineHud', "", %tag, %count, "Oracle Cycle", "", OracleVehicle, $VehicleMax[OracleVehicle] - $VehicleTotalCount[%team, MeBaDGravVehicle] );
			%count++;
		messageClient( %client, 'SetLineHud', "", %tag, %count, "Nova Cycle", "", MeBaDGravVehicle, $VehicleMax[MeBaDGravVehicle] - $VehicleTotalCount[%team, MeBaDGravVehicle] );
			%count++;

		if (!$DisableRaceTanks) {
		     messageClient( %client, 'SetLineHud', "", %tag, %count, "HellFire Tank", "", MeBaDTankVehicle, $VehicleMax[MeBaDTankVehicle] - $VehicleTotalCount[%team, MeBaDTankVehicle] );
				%count++;
		     messageClient( %client, 'SetLineHud', "", %tag, %count, "Urban Tank", "", AssaultVehicle, $VehicleMax[AssaultVehicle] - $VehicleTotalCount[%team, AssaultVehicle] );
			     %count++;
		}

		if ($FreeStyleMode) {
		     messageClient( %client, 'SetLineHud', "", %tag, %count, "Free-Style MPB", "", MobileBaseVehicle, $VehicleMax[MobileBaseVehicle] - $VehicleTotalCount[%team, MobileBaseVehicle] );
			     %count++;
		}

//		messageClient( %client, 'SetLineHud', "", %tag, %count, "SCOUT FLIER", "", ScoutFlyer, $VehicleMax[ScoutFlyer] - $VehicleTotalCount[%team, ScoutFlyer] );
//			%count++;
//		messageClient( %client, 'SetLineHud', "", %tag, %count, "TRANSPORT", "", HAPCFlyer, $VehicleMax[HAPCFlyer] - $VehicleTotalCount[%team, HAPCFlyer] ); 
//			%count++;

		%station.lastCount = %count;
	}

	function clearVehicleCount(%team) {
		parent::clearVehicleCount(%team);
	   	$VehicleTotalCount[%team, ScoutVehicle]      = 0;  // ameri
	   	$VehicleTotalCount[%team, OracleGravVehicle] = 0;  // Oracle
	   	$VehicleTotalCount[%team, MeBaDGravVehicle]  = 0;  // Nova
	   	$VehicleTotalCount[%team, MeBaDTankVehicle]  = 0;  // Hellfire
	   	$VehicleTotalCount[%team, AssaultVehicle]    = 0;  // Urban
	   	$VehicleTotalCount[%team, MobileBaseVehicle] = 0;  // MPB
	}

	function RaceGame::missionLoadDone(%game) {
	   	//default version sets up teams - must be called first...
	   	DefaultGame::missionLoadDone(%game);

		for(%i = 1; %i < (%game.numTeams + 1); %i++)
			$teamScore[%i] = 0;
	}

	function RaceGame::activatePackages(%game) {
		DefaultGame::activatePackages(%game);
	}

	function RaceGame::deactivatePackages(%game) {
		DefaultGame::deactivatePackages(%game);
	}

	function RaceGame::initGameVars(%game) {
		%game.VehicleKillTime	=	30;
		%game.VehicleKill		=	200;

		if(isFile("prefs/RaceStats.cs")) {
			exec("prefs/RaceStats.cs");
		}

		$MeBaDMission = strreplace($CurrentMission," ","_");

		for (%i = 1; %i < 32; %i++) {
			$TeamName[%i] = "";
		}
	}

//--------------------------------------------------------------------------------------------------------------------

	function RaceGame::missionLoadDone(%game) {
		for(%i = 1; %i <= %game.numTeams; %i++) {
			$teamScore[%i] = 0;
		}

		DefaultGame::missionLoadDone(%game);
	}

	function RaceGame::setUpTeams(%game) {
		if ((%group = nameToID("MissionGroup/Teams")) == -1) {
			return;
		}

		error("Setting up teams...");
		
		%dropSet = new SimSet("TeamDrops0");
		MissionCleanup.add(%dropSet);
		%group.setTeam(0);
		%game.numTeams = 1; // 32 ?
		setSensorGroupCount(32);

		for (%i = 0; %i < ClientGroup.getCount(); %i++) {
			%client = ClientGroup.getObject(%i);
			%game.UpdateColorMask(%game, %client);
		}

		setSensorGroupCount(%game.numTeams);
	}

	function RaceGame::pickTeamSpawn(%game, %team) {
	   DefaultGame::pickTeamSpawn(%game, 0);
	}

	function RaceGame::claimSpawn(%game, %obj, %newTeam, %oldTeam) {
	   %newSpawnGroup = nameToId("MissionCleanup/TeamDrops0");
	   %newSpawnGroup.add(%obj);
	}

	function RaceGame::clientJoinTeam( %game, %client, %team, %respawn ) {
	   %game.assignClientTeam( %client );
	   %game.spawnPlayer( %client, %respawn );
	}

	function RaceGame::assignClientTeam(%game, %client) {
		%client.team = 0;

		for (%i = 1; %i < 32; %i++) {
			%game.teamArray[%i] = false;
		}

		for (%i = 0; %i < ClientGroup.getCount(); %i++) {
			%cl = ClientGroup.getObject(%i);
			if (%cl.team != 0) {
				%game.teamArray[%cl.team] = true;
			}
		}

		for (%i = 1; %i < 32; %i++) {
			if (! %game.teamArray[%i]) {
				%client.team = %i;
				break;
			}
		}

		setTargetSkin(%client.target, %client.skin);
		%client.justEntered = true;

		if (%client.bestlap < 1) {
			%client.BestLap = 300;
		}

		error ("assigning Client " @ %client.nameBase @ " to team " @ %client.team);
		messageAll( 'MsgClientJoinTeam', '\c1%1 has joined the race!', %client.name, "", %client, %client.team );
		updateCanListenState( %client );
	}

	function RaceGame::playerSpawned(%game, %player, %armor) {
		%player.MMrecharge = "FULL";
		DefaultGame::playerSpawned(%game, %player, %armor);
		%game.updateColorMask(%player.client);
		%player.setInvincible(true); // hows that for energized :D
	}

	function RaceGame::equip(%game, %player) {
		for(%i =0; %i<$InventoryHudCount; %i++) {
			%player.client.setInventoryHudItem($InventoryHudData[%i, itemDataName], 0, 1);
		}

		%player.setInventory(RepairKit,1);
		%player.setInventory(TargetingLaser, 1);
		%player.setInventory(RepairPack,1);
		%player.weaponCount = 0;
		%player.use("TargetingLaser");
		%player.client.outOfBounds = true;
	}

	function RaceGame::timeLimitReached(%game) {
		echo("LOG: game over (timelimit)");
		%game.gameOver();
		schedule( 5000, %game, cycleMissions );
	}

	function RaceGame::scoreLimitReached(%game) {
		// no console errors
	}

	function RaceGame::gameOver(%game) {

		messageAll('MsgGameOver', "Racing has ended!~wvoice/announcer/ann.gameover.wav" );

		$RaceLaps = 1;
		$RaceGateDistance = 75;
		error("Exporting Racing Stats...");

		export("$RaceTimes::*", "prefs/RaceStats.cs");
		clearRaceParms(); // end a race if is one
		cancel($countdownsch); // cancel countdown if there is one
		cancel($defaultsch);   // cancel set race end
		cancel($setracerssch); // cancel racers

		DefaultGame::gameOver(%game, %client);

		messageAll('MsgClearObjHud', "");

// clear client scores - On join and mission change (clientdropready)
//		for (%dis = 0; %dis < ClientGroup.getCount(); %dis++) {
//			%disdood = ClientGroup.getObject(%dis);
//			%game.resetScore(%game, %disdood);
//			%disdood.CameraName = ""; // clear everyone's camera :)
//			//error("Reseting " @ ClientGroup.getObject(%dis));
//		}

		// Clear team scores
//		for(%j = 1; %j <= %game.numTeams; %j++) {
//			$TeamScore[%j] = 0; // no team score anyway
//		}
	}

	function RaceGame::sendDebriefing(%game, %client) {

		//error("Sending debriefing... " @ %client);

		%count = ClientGroup.getCount();
		%winnerscore = 0;

		for (%i = 0; %i < %count; %i++) {
			%cl = ClientGroup.getObject(%i);
			if (%winnerscore < %cl.score) {
				%winner = %cl.nameBase;  // find out who's got the most points!
				%winnerscore = %cl.score;
			}
		}

		if ( %winnerscore > 0 ) {
			messageClient( %client, 'MsgDebriefResult', "", '<just:center>%1 wins!', %winner );
		} else {
			messageClient( %client, 'MsgDebriefResult', "", '<just:center>Nobody wins.' );
		}

		// Header of the score box
		messageClient( %client, 'MsgDebriefAddLine', "", '<spush><color:00dc00><font:univers condensed:18>RACER<lmargin%%:43>BEST TIME<lmargin%%:65>FINISHES<lmargin%%:85>RACES<spop>' );

		for ( %j = 0; %j < %count; %j++ ) {
			%players = ClientGroup.getObject(%j); // ran out of cl client var's heh

			if (%players.FirstFinish $= "") {
				%players.FirstFinish = 0;
			}
			if (%players.SecondFinish $= "") {
				%players.SecondFinish = 0;
			}
			if (%players.ThirdFinish $= "") {
				%players.ThirdFinish = 0;
			}
			if (%players.TotalRaces $= "") {
				%players.TotalRaces = 0;
			}

			%besttime = %players.bestlap == 300 ? "---" : %players.bestlap;
			%score = %players.FirstFinish @ "/" @ %players.SecondFinish @ "/" @ %players.ThirdFinish;

			messageClient( %client, 'MsgDebriefAddLine', "", '<lmargin:0><clip%%:40> %1</clip><lmargin%%:42><clip%%:20> %2</clip><lmargin%%:64><clip%%:20> %3</clip><lmargin%%:85><clip%%:20>%4</clip>', %players.name, %besttime, %score, %players.TotalRaces );
		}
	}

	function RaceGame::resetScore(%game, %client) {
			//error("Reseting score : " @ %client.nameBase @ " - " @ %client.score);
			%client.score = 0;
			%client.FirstFinish = 0;
			%client.SecondFinish = 0;
			%client.ThirdFinish = 0;
			%client.TotalRaces = 0;
			%client.bestlap = 300;
	}

	function RaceGame::clientMissionDropReady(%game, %client) {
		%game.resetScore(%game, %client);
		messageClient(%client, 'MsgMissionDropInfo', '\c0You are in mission %1 (%2).', $MissionDisplayName, $MissionTypeDisplayName, $ServerName );
		if ($RaceLaps > 1) {
			messageClient(%client, 'msgRaceLaps', '\c3***\c5This Race has %1 laps\c3***', $RaceLaps);
		} else {
			messageClient(%client, 'msgRaceLaps', '\c3***\c5This Race has 1 lap\c3***');
		}

		if (($RaceTimes::BestLapTime_[$MeBaDMission] < 5) && ($CurrentMissionType $= "Race")) {
			$RaceTimes::BestLapTime_[$MeBaDMission] = 300;
			$RaceTimes::LapTimeHolder_[$MeBaDMission] = "TheServer";
			error("No Time for " @ $CurrentMission @ " Creating one...");
		}
		messageClient(%client, 'MsgRaceHighScores', '\c0Best Finish Time: \c2%1 \c0- Set by: \c2%2', $RaceTimes::BestLapTime_[$MeBaDMission], $RaceTimes::LapTimeHolder_[$MeBaDMission] );
		messageClient(%client, 'MsgClientReady', "", %game.class);
		DefaultGame::clientMissionDropReady(%game, %client);
	}

	function RaceGame::updateKillScores(%game, %clVictim, %clKiller, %damageType, %implement) {
		// no kills in this game
	}

	function RaceGame::checkScoreLimit(%game, %team) {
		// not used
	}

	function RaceGame::enterMissionArea(%game, %playerData, %player) {
		%player.client.outOfBounds = false;
		messageClient(%player.client, 'EnterMissionArea', '\c2Welcome back %1!~wvoice/announcer/ANN.ib.wav', %player.client.nameBase);
	}

	function RaceGame::leaveMissionArea(%game, %playerData, %player) {

		if (%player.client.IsInRace) {
			%player.client.outOfBounds = true;
			messageAll('MsgRaceDisqualified', '\c1%1 has been \c5DISQUALIFIED \c1for leaving the mission area!~wvoice/bot1/gbl.aww.wav', %player.client.nameBase);
			$Racercount--;
			%player.client.IsInRace = false;
			%player.LapTimeStart = 0;
		
			if ($RaceTornyMode) {
				schedule(3000, 0, "delayForceObserver", %player.client);
			}

			if ($RacerCount < 1) {
				clearRaceParms();
			}
		} else {
			messageclient(%player.client, 'LeaveMissionArea', '\c2%1...where are you going?~wvoice/announcer/ANN.oob.wav', %player.client.nameBase);
		}
	}

	function RaceGame::createPlayer(%game, %client, %spawnLoc, %respawn) {
		DefaultGame::createPlayer(%game, %client, %spawnLoc, %respawn);
		%player = %client.player;
		%client.IsInRace = false;
		%player.LapTimeStart = 0;
		%player.client.outOfBounds = true;
	}

	function RaceGame::UpdateColorMask(%game, %client) {
		%redMask = 0;
		
		for (%i = 0; %i < ClientGroup.getCount(); %i++) {
			%cl = ClientGroup.getObject(%i);
	//		if (!%cl.outOfBounds) { // make everyone look like a bad guy
	//			%redMask |= (1 << %cl.team);
	//		}
			if (%cl.team != %client.team) {
				%redMask |= (1 << %cl.team);
			}
		}
		setSensorGroupColor(%client.team, 0xfffffffe, "0 255 0 255");
		setSensorGroupColor(%client.team, %redMask, "255 128 0 160"); // no see no worries :)
	}

//=-=-=-=-=-=-=-=-=-=-=-=-=
// Actual Game CTRL code
//=-=-=-=-=-=-=-=-=-=-=-=-=

	// Stupid shit
	function RaceGame::countFlips() { }
	function RaceGame::AIplayercaptureFlipflop() { }

	function RaceGame::claimFlipflopResources(%game, %flipflop, %team) {

		DefaultGame::claimFlipflopResources(%game, %flipflop, %team);

			//%flipflop.name = "Race Start Switch";

			$Raceflipflop = %flipflop;
			if (!$FreeStyleMode) {
				if (!$CurrentRace) {
					%game.Countdown();
					$CurrentRace = true;
					for (%i = 0; %i < ClientGroup.getCount(); %i++) { // 1.1 making the grav invincible for start
						ClientGroup.getObject(%i).player.MMID.setInvincibleMode(25000,0.02);
					}
				}
			} else {
				
				Messageall('msgNoRace', '\c5No racing during Freestyle Mode!');
				%flipflop.team = "";
			}
	}

	function RaceGame::Countdown() { // play some wav's to start a race and start the drag tree
		error("Starting race in 18 secs...");
			$setracerssch = schedule(18250, 0, "SetCurrentRacers");
			$countdownsch = schedule(3000, 0, "SyncCountDown", 15);
			$defaultsch = schedule(180000, 0, "clearRaceParms");
	}

	function SyncCountdown(%number) {
		//error("Number : " @ %number);
		%secondargv[15] = "Race begins in 15 seconds.~wvoice/Announcer/ANN.prepare.wav";
		%secondargv[10] = "Race begins in 10 seconds.~wfx/misc/hunters_10.wav";
		%secondargv[5] = "Race begins in 5 seconds.~wfx/misc/hunters_5.wav";
		%secondargv[4] = "Race begins in 4 seconds.~wfx/misc/hunters_4.wav";
		%secondargv[3] = "On the line!~wfx/misc/hunters_3.wav";
		%secondargv[2] = "Get Set...~wvoice/announcer/ann.match_begins.wav";
		%secondargv[0] = "\c2*****\c3G00000000000000000000000000\c2*****";

		%dragtree[15] = "1 Red 5000";
		%dragtree[10] = "2 Yellow 5000";
		%dragtree[5] = "3 Yellow 6000";
		%dragtree[3] = "4 Yellow 5000";
		%dragtree[2] = "5 Yellow 3000";
		%dragtree[0] = "Green";

		if (%number >= 0) {
			if (%secondargv[%number] !$= "") {
				// chat menu
				Messageall('msgRaceStarts', %secondargv[%number]);

				// Drag Tree
				if (%dragtree[%number] !$= "") {
					CreateDragTreeLight(getword(%dragtree[%number], 0), getword(%dragtree[%number], 1), getword(%dragtree[%number], 2));

					if (%dragtree[%number] $= "Green") {
						CreateDragTreeLight("go1", "Green", 3000);
						CreateDragTreeLight("go2", "Green", 3000);
					}
				}
			}

			if (%number > 0) {
				%newnum = %number - 1;
				cancel($countdownsch);
				$countdownsch = schedule(1000, 0, "SyncCountdown", %newnum);
			}
		}
	}

	function CreateDragTreeLight(%light, %color, %time) {
		if (%time) {
			%lightname = "DragTree_" @ %light;
			%position = %lightname.position;
			%emitter = "DragTree" @ %color @ "Emitter";
			%partname = %lightname @ "Light";
	
					new ParticleEmissionDummy(%partname) {
						position = %position;
						rotation = "1 0 0 0";
						scale = "1 1 1";
						dataBlock = "defaultEmissionDummy";
						emitter = %emitter;
						velocity = "0";
					};
	
			//error("Creating Drag Light Emitter : " @ %lightname @ " - " @ %emitter @ " - " @ %position);
	
			schedule(%time, 0, "DeleteDragLight", %partname);
		}
	}

	function DeleteDragLight(%this) {
		//error("Deleting Drag Light : " @ %this);
		%this.delete();
	}

	function SetCurrentRacers() {

		if ($RaceTornyMode) {
			$Host::TournamentMode = true;
			schedule(7000, 0, "RaceTornyModeForce");
		}

		$RacerCount = 0;

		for (%i = 0; %i < ClientGroup.getCount(); %i++) {
			%client = ClientGroup.getObject(%i);

			%playerpos = %client.player.getposition();
			%distance = vectorDist( %playerpos, StartLine.position );

			if ((%distance <= 45) && (%client.player.isMounted())) {
				if (strlen(%racingclients) < 1) { // this is only for the first one
					%racingclients = "\c1" @ %client.nameBase;
				} else {
					%racingclients = %racingclients @ "\c2, \c1" @ %client.nameBase;
				}
				%client.IsInRace = true;
				schedule(2500, 0, "CheckGate", %client); //start checkin the race progress
				$Racercount++;
				%client.player.lapTimeStart = getSimTime();
				%client.TotalRaces++;
				%client.score = %client.score + 10;
				%client.outOfBounds = true; // Keep his ass OB so the colors don't work
				setGate(%client, 1);
				schedule(5000, 0, "updateRacePrint", %client);

				// Version 1.1 - 10 sec invulerable!
				ClientGroup.getObject(%i).player.MMID.setInvincibleMode(10000,0.02);
			}
			//error("Client: " @ %client.nameBase @ " - Distance: " @ %distance @ " - Racers: " @ $Racercount @ " - " @ %racingclients);
		}

		if (strlen(%racingclients) < 1) { // no racer to start ?
			%racingclients = "\c3NONE!";
			clearRaceParms();
		}

		messageall('msgRaceRacers', "\c5Current Racers: " @ %racingclients);
//		schedule (10000, 0, "ClearInvin");
	}

//	function ClearInvin() {
//		for (%i = 0; %i < ClientGroup.getCount(); %i++) { // 1.1 making the grav invincible for start
//			ClientGroup.getObject(%i).player.MMID.invincible = false;
//		}
//	}

	function setGate(%client, %gate) {
		%client.gate = %gate;
		%lastgate = %gate - 1;
		%oldgate = "Gate_" @ %lastgate;
		%newgate = "Gate_" @ %gate;

		//error("Setting Gate : " @ %newgate @ " for " @ %client);

		if (isObject(%oldgate)) {
			// the must have cleared a gate .. so give them dough for it ! :)
			%client.score = %client.score + 10;
			//error("Deleteing old gate : " @ %oldgate);
			%client.gatewaypoint.delete();
		}

		if (isObject(%newgate)) { // if it's not .. only finish line left
			%position = %newgate.position;
			%name = %client.nameBase @ " - Gate " @ %gate;
		} else {
			%position = FinishLine.position;
			%name = %client.nameBase @ " - FinishLine";
		}

		messageClient(%client, 'msgRaceWaypoint', "~wfx/misc/target_waypoint.wav");

		%client.gatewaypoint = new WayPoint() {
	      	position = %position;
			dataBlock = "WayPointMarker";
			team = %client.team;
			name = %name;
	   	};
		//error("Team waypoint : " @ %client.team SPC Test.team);

   		MissionCleanup.add(%client.gatewaypoint);
	}

	function CheckGate(%client) {
		if (%client.IsInRace) {
			%gate = "Gate_" @ %client.gate;

			%playerpos = %client.player.getTransform();
			%gatedistance = vectorDist( %playerpos, %gate.position );

			if ((%gatedistance <= $RaceGateDistance) && ($CurrentRace) && (%client.IsInRace)) {
				//error ("gate passed : " @ %client.nameBase SPC %gate);

				%nextgate = %client.gate + 1;
				%nextgatename = "Gate_" @ %nextgate;

				if (!isObject(%nextgatename)) {
					schedule(250, 0, "CheckFinishLine", %client);
					setGate(%client, %nextgate);
					return; // no more checking gates
				} else {
					setGate(%client, %nextgate);
				}
			}
			schedule(300, 0, "CheckGate", %client);
		}
	}

	function CheckFinishLine(%client) {

		if (%client.IsInRace) {

			%lastgate = %client.gate - 1;
			%oldgate = "Gate_" @ %lastgate;

			//error ("Checking distance for: " @ %client.nameBase);

			%playerpos = %client.player.getTransform();
			%finishdistance = vectorDist( %playerpos, FinishLine.position );

			if ((%finishdistance <= 76) && ($CurrentRace)) {
				if (!$FirstPlace) {
					$FirstPlace = true;
					%client.IsInRace = false;
					messageall('msgRaceWon', '\c3%1 \c2has won the race!~wvoice/fem5/gbl.woohoo.wav', %client.nameBase);
					$RacerCount--;
					%client.score = %client.score + 100;
					%client.FirstFinish++;
					cancel($defaultsch);
					$defaultsch = schedule(30000, 0, "clearRaceParms"); // in 30 secs .. race is over either way
				} else if (!$SecondPlace) {
					$SecondPlace = true;
					%client.IsInRace = false;
					messageall('msgRaceWon', '\c3%1 \c2takes second!~wvoice/fem3/gbl.woohoo.wav', %client.nameBase);
					%client.score = %client.score + 75;
					$RacerCount--;
					%client.SecondFinish++;
				} else if (!$ThirdPlace) {
					$ThirdPlace = true;
					%client.IsInRace = false;
					messageall('msgRaceWon', '\c3%1 \c2takes Third!~wvoice/fem1/gbl.woohoo.wav', %client.nameBase);
					$RacerCount--;
					%client.score = %client.score + 50;
					%client.ThirdFinish++;
				}

				%laptime = getSimTime() - %client.player.LapTimeStart;
				%laptime = %laptime / 1000;

				if ((%client.bestlap > %laptime) || (%client.bestlap $= "")) {  // in case they don't have a record yet
					%client.bestlap = %laptime;
					%isnew = "\c1New Personal Record!";
				}

				messageClient(%client, 'msgRaceTime', '\c2Your Best Finish Time:\c5 %1 %2', %client.bestlap, %isnew, getClientRaceRank(%client));

				if ($RaceTimes::BestLapTime_[$MeBaDMission] > %laptime) {
					$RaceTimes::BestLapTime_[$MeBaDMission] = %laptime;
					$RaceTimes::LapTimeHolder_[$MeBaDMission] = %client.nameBase;

					messageall('msgRaceLapTime', '\c3%1 \c2FinishTime: \c5%2 secs \c3NEW SERVER RECORD~wvoice/announcer/ann.yardsale.wav', %client.nameBase, %laptime);

					error("Track record broken for: " @ $CurrentMission @ " - by: " @ %client.nameBase);
					export("$RaceTimes::*", "prefs/RaceStats.cs");

					%client.score = %client.score + 100; // give him the gold for a job well done !
				} else {
					messageall('msgRaceLapTime', '\c3%1 \c2laptime: \c5%2 secs', %client.nameBase, %laptime);
				}

				if ($RacerCount < 1) {
					if (!$SecondPlace) { // your a 1st place only peep :D
						%client.score = %client.score + 50;
						messageAll('msgRaceBonus', '\c2%1 \c3recieves 50 race credits for being the only Survivor!', %client.nameBase);
					}
					clearRaceParms();
				}

				if (isObject(%client.gatewaypoint)) {
					//error("Deleteing old gate : " @ %oldgate);
					%client.gatewaypoint.delete();
				}
				return; // stop checkin!
			}
			schedule(250, 0, "CheckFinishLine", %client);
		}
	}

	function getClientRaceRank(%client) {
		%rank = 1;
		for (%i = 0; %i < ClientGroup.getCount(); %i++) {
			if (%client.score < ClientGroup.getObject(%i).score) {
				%rank++;
			}
		}
		return %rank;
	}

	function clearRaceParms() {
		cancel($defaultsch);
		error("Clearing Current Race Parms...");
		if ($CurrentRace) {
			messageall('msgRaceOver', "\c3Race Over...");
			schedule(2000, 0, "messageall", 0, "~wfx/misc/flag_return.wav");
		}
		$Racercount = 0;
		$FirstPlace = false;
		$SecondPlace = false;
		$ThirdPlace = false;
		$RaceFlipFlop.team = ""; // so we can hit it again :P
		$CurrentRace = false;
		$Host::TournamentMode = false; // false either way :o

		for (%i = 0; %i < ClientGroup.getCount(); %i++) {
			%client = ClientGroup.getObject(%i);
			%client.IsInRace = false;
			%client.gate = 0;
			if (isObject(%client.gatewaypoint)) {
				%client.gatewaypoint.delete();
			}
			messageClient(%client, 'msgRaceTime', "", 0, "", getClientRaceRank(%client));
		}
	}

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
// End race with everyone dead
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

	function RaceGame::displayDeathMessages(%game, %clVictim, %clKiller, %damageType, %implement) {
		DefaultGame::displayDeathMessages(%game, %clVictim, %clKiller, %damageType, %implement);
		if (($CurrentRace) && (%clVictim.IsInRace)) {
			%clVictim.gatewaypoint.delete();
			%clVictim.IsInRace = false;
			messageall('msgRaceOut', '\c3%1 \c2is out of the race!', %clVictim.nameBase);
			$Racercount--;
			if ($RacerCount < 1) {
				clearRaceParms();
			} else {
				if ($RaceTornyMode) {
					if (!%client.IsInRace) {
						schedule(3000, 0, "delayForceObserver", %clVictim);
					}
				}
			}
		}
	}

//=-=-=-=-=-=-=-=
// Score Screen
//=-=-=-=-=-=-=-=

	function RaceGame::updateScoreHud(%game, %client, %tag) {
	   messageClient( %client, 'SetScoreHudHeader', "", "" );
	   messageClient(%client, 'SetScoreHudSubheader', "", '<tab:10,230,331,397,465,530>\tRacer(s)\tBest Time\t1st(s)\t2nd(s)\t3rd(s)\tRace(s)');

		%observerCount = 0;
		%index = 0;

		for (%j = 0; %j < ClientGroup.getCount(); %j++) {
			%cl = ClientGroup.getObject(%j);

			if (%cl.team != 0) {
				%clfirst = mFloatLength( %cl.FirstFinish, 0 );
				%clsecond = mFloatLength( %cl.SecondFinish, 0 );
				%clthird = mFloatLength( %cl.ThirdFinish, 0 );
				%cltotal = mFloatLength( %cl.TotalRaces, 0 );
				%clStyle = %cl == %client ? "<color:dcdcdc>" : "";

				%clbesttime = %cl.bestlap;

				if (%clbesttime == 300) { // they have no time really :\
					%clbesttime = "-- -- -- ";
				}

				if (%client.team != 0) {
					messageClient( %client, 'SetLineHud', "", %tag, %index, 
						'%6<tab:10, 450>\t<clip:200>%1</clip><rmargin:285><just:right>%7<rmargin:360><just:right>%2<rmargin:429><just:right>%3<rmargin:494><just:right>%4<rmargin:570><just:right>%5',
						%cl.name, %clfirst, %clsecond, %clthird, %cltotal, %clStyle, %clbesttime );
				} else { //else for observers, create an anchor around the player name so they can be observed
					messageClient( %client, 'SetLineHud', "", %tag, %index, '%5<tab:10, 450>\t<clip:200><a:gamelink\t%6>%1</clip><rmargin:285><just:right>%8<rmargin:360><just:right>%2<rmargin:429><just:right>%3<rmargin:494><just:right>%4<rmargin:570><just:right>%7', 
						%cl.name, %clfirst, %clsecond, %clthird, %clStyle, %cl, %cltotal, %clbesttime );
				}
				%index++;
			} else {
				%observerCount++;
			}
		}

		messageClient( %client, 'SetLineHud', "", %tag, %index, "");
			%index++;
		messageClient(%client, 'SetLineHud', "", %tag, %index, "<just:center><font:Univers Condensed:22><color:FF9955>-=[ <color:55FF55>Server Record: " @ $RaceTimes::BestLapTime_[$MeBaDMission] @ "        Set by: " @ $RaceTimes::LapTimeHolder_[$MeBaDMission] @ " <color:FF9955>]=-");
			%index++;

		if (%observerCount > 0) {
			messageClient( %client, 'SetLineHud', "", %tag, %index, "");
				%index++;
			messageClient(%client, 'SetLineHud', "", %tag, %index, '<tab:7, 310><spush><font:Univers Condensed:22>\tOBSERVERS (%1)<rmargin:260>', %observerCount);
				%index++;
			for (%i = 0; %i < ClientGroup.getCount(); %i++) {
			    %cl = ClientGroup.getObject(%i);

				%clbesttime = %cl.bestlap;

				if (%clbesttime == 300) { // they have no time really :\
					%clbesttime = "-- -- -- ";
				}

			    //if this is an observer
			    if (%cl.team == 0) {
					%clfirst = mFloatLength( %cl.FirstFinish, 0 );
					%clsecond = mFloatLength( %cl.SecondFinish, 0 );
					%clthird = mFloatLength( %cl.ThirdFinish, 0 );
					%cltotal = mFloatLength( %cl.TotalRaces, 0 );
					%clStyle = %cl == %client ? "<color:dcdcdc>" : "";

//				     %obsTime = getSimTime() - %cl.observerStartTime;
//					%obsTimeStr = %game.formatTime(%obsTime, false);
//					messageClient( %client, 'SetLineHud', "", %tag, %index, '<tab:20, 310>\t<clip:150>%1</clip><rmargin:260><just:right>%2', %cl.name, %obsTimeStr );
//
					messageClient( %client, 'SetLineHud', "", %tag, %index, '%5<tab:10, 450>\t<clip:200><a:gamelink\t%6>%1</clip><rmargin:285><just:right>%8<rmargin:360><just:right>%2<rmargin:429><just:right>%3<rmargin:494><just:right>%4<rmargin:570><just:right>%7', 
						%cl.name, %clfirst, %clsecond, %clthird, %clStyle, %cl, %cltotal, %clbesttime );
				  %index++;
			    }
			 }
		   }
		   //clear the rest of Hud so we don't get old lines hanging around...
		   messageClient( %client, 'ClearHud', "", %tag, %index );
	}

	function displayObserverHud(%client, %targetClient, %potentialClient) {

		if (strlen(%client.CameraName) > 1) {
			%motd3 = "<color:5599FF>Camera: " @ %client.CameraName @ "          ";
		}

		%motd = "<color:FFFF00>Welcome to MeBaD\'s Race mod  -  " @ $RaceModVersion @ "\n";
//		%motd2 = "<color:FF5533>Map: " @ $CurrentMission @ "   -    Server Record: " @ $RaceTimes::BestLapTime_[$MeBaDMission] @ "   -   Set by: " @ $RaceTimes::LapTimeHolder_[$MeBaDMission] @ "\n";

		if (%targetClient > 0) {
			bottomPrint(%client, %motd @ "<color:5599FF>You are now observing: " @ getTaggedString(%targetClient.name), 0, 2);
		} else if (%potentialClient > 0) {
			bottomPrint(%client, %motd SPC %motd3 @ "<color:5599FF>Observer Fly Mode: " @ getTaggedString(%potentialClient.name), 0, 2);
		} else {
			bottomPrint(%client, %motd SPC %motd3, 0, 3);    
		}
	}

	function updateRacePrint(%client, %hackme) {
		%laptime = "<font:univers bold:16><color:FFFF00>RunTime: " @ mfloor((getSimTime() - %client.player.LapTimeStart) / 1000) @ " secs";
		%MeBaDCheatoffset = "                                                 "; // offset to it's to the right of vehiclehud :)
		%NOS = "<font:univers bold:16><color:FFFF00>NOS recharge : " @ %client.player.MMrecharge;

		if (isObject(%client.player)) {
			if (!%client.IsInRace) {
				commandToClient(%client, 'bottomPrint', %MeBaDCheatoffset @ %NOS, 3);
			} else {
				commandToClient(%client, 'bottomPrint', %laptime @ %MeBaDCheatoffset @ %NOS, 3);
			}
		}

		if ((%client.IsInRace) && (!%hackme)) {
			schedule(1000, 0, "UpdateRacePrint", %client);
		}
	}

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
// Admin commands - these are NOT ServerCmd for a reason!!!!!
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

	function SetFreeStyleMode(%admin, %admin) {
		if (%admin.isSuperadmin) {
			if (!$FreeStyleMode) {
				clearRaceParms(); // clear all current stuffs
				cancel($countdownsch); // cancel countdown if there is one
				cancel($defaultsch);   // cancel set race end
				cancel($setracerssch); // cancel racers
				$FreeStyleMode = true;
				messageAll('MsgAdminForce', '\c0Server Checking: \c2%1 \c5enabled Fr33Styl3 M0d3! \c1(No Racing)', %admin.nameBase);
			} else {
				$FreeStyleMode = false;
				messageAll('MsgAdminForce', '\c0Server Checking: \c2%1 \c5disabled Fr33Styl3 M0d3! \c1(Racing on)', %admin.nameBase);
			}
		}
	}

	function AdminStopRace(%admin) {
		if (%admin.isSuperadmin) {
			if ($CurrentRace) {
				clearRaceParms();
				messageAll('MsgAdminForce', '\c0Server Checking: \c2%1 \c5stopped the current race!', %admin.nameBase);
				cancel($countdownsch); // cancel countdown if there is one
				cancel($defaultsch);   // cancel set race end
				cancel($setracerssch); // cancel racers
			}
		}
	}

	function StripPubAdmins(%admin) {
		if (%admin.isSuperAdmin) {
			echo("Purging Public Admins...");

			messageAll('MsgAdminForce', '\c0Server Checking: \c5Purging Public Admins...');

			for(%i = 0; %i < ClientGroup.getCount(); %i++) {
				 %client = ClientGroup.getObject(%i);
				 if ((%client.isAdmin) && (!%client.isSuperAdmin)) {
					%client.isAdmin = false;
					messageAll('MsgAdminForce', '\c2%2 \c5has stipped \c3%1 \c5of his/her admin rights!', %client.nameBase, %admin.nameBase);
					error("Sadmin stipped : " @ %client.nameBase);
				}
			}
		}
	}
	
	function SetTornyRacingMode(%admin) {
		if (%admin.isSuperadmin) {
			if (!$RaceTornyMode) {
				$RaceTornyMode = true;
				messageAll('MsgAdminForce', '\c0Server Checking: \c2%1 \c5enabled Race Torney Mode.', %admin.nameBase);
			} else {
				$RaceTornyMode = false;
				$Host::TournamentMode = false;
				messageAll('MsgAdminForce', '\c0Server Checking: \c2%1 \c5disabled Race Torney Mode.', %admin.nameBase);
			}
		}
	}

	function ctrlRaceModWeapons(%admin) {
		if (%admin.isSuperadmin) {
			if ($RaceModEnableWeapons) {
				$RaceModEnableWeapons = false;
				messageAll('MsgAdminForce', '\c0Server Checking: \c2%1 \c5disabled MeBaD Kart Mode.', %admin.nameBase);
			} else {
				$RaceModEnableWeapons = true;
				messageAll('MsgAdminForce', '\c0Server Checking: \c2%1 \c5enabled MeBaD Kart Mode.', %admin.nameBase);
			}
		}
	}

	function RaceTornyModeForce() {
		if (($RaceTornyMode) && ($CurrentRace)) {
			for(%i = 0; %i < ClientGroup.getCount(); %i++) {
				%client = ClientGroup.getObject(%i);
				if ((!%client.IsInRace) && (%client.team > 0)) {
					Game.forceObserver(%client, "adminforce");
					messageClient(%player, 0, "~wfx/misc/warning_beep.wav");
				}
			}
		}
	}

	// this will get changed if I bring in any other vehicles
	function RaceHandleVehicle(%admin) {
		if (%admin.isSuperadmin) {
			if ($DisableRaceTanks) {
				$DisableRaceTanks = false;
				messageAll('MsgAdminForce', '\c0Server Checking: \c2%1 \c5ENABLED Tanks.', %admin.nameBase);
			} else {
				$DisableRaceTanks = true;
				messageAll('MsgAdminForce', '\c0Server Checking: \c2%1 \c5DISABLED Tanks.', %admin.nameBase);
			}
		}
	}

	//only list Race maps :)
	function serverCmdGetMissionTypes( %client, %key ) {
		for ( %type = 0; %type < $HostTypeCount; %type++ ) {
			if ($HostTypeDisplayName[%type] $= "Race") {
				messageClient( %client, 'MsgVoteItem', "", %key, %type, "", $HostTypeDisplayName[%type], true );
			}
		}
	}

	function delayForceObserver(%client) { // so we can let them see their dead
		Game.forceObserver(%client, "adminforce");
	}

	function ServerCmdBWAdminRegister(%client) {
		messageClient(%client, 'msgCookie', '\c3BWAdmin Register... What ya want, a cookie?');
	}

	function ServerCmdTriconRegisterClient(%client) {
		messageClient(%client, 'msgCookie', '\c3Tricon Register... What ya want, a cookie?');
	}

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
// RaceMod Weapon Mount - (This is a cheat to do it quick)
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-==-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	function checkPlayerWeaponPack(%player, %obj, %mount) {

		%obj.setCloaked(false);      //
		%player.setCloaked(false);   // 
		%obj.unmountImage(0);        // So they can't mount 2 things .. cause that's bad !
		%obj.unmountImage(1);        //
		%obj.unmountImage(2);        //
		%obj.unmountImage(3);        //
		%obj.setRepairRate(0);

		//Modules
		// Repairpack
			if (%player.invRepairPack) {
				ServerPlay3D(MBLSwitchSound, %player.getTransform());
					%obj.setRepairRate(0.007);
			}
		if ($RaceModEnableWeapons) {
			if (!%mount) {
				ServerPlay3D(BasePowerOff, %player.getTransform());
			} else {
				if (%player.invMotionSensorDeployable) {
					%obj.playAudio(1, SatchelChargeActivateSound);
					%obj.mountImage(Blower, 0); // put it in a slot we don't clear
// Cloak
				} else if (%player.invCloakingPack) {
					ServerPlay3D(MBLSwitchSound, %player.getTransform());
						%obj.setCloaked(%mount);
						%player.setCloaked(%mount);
// Shrike Blaster
				} else if (%player.invEnergyPack) {
					ServerPlay3D(AASwitchSound, %player.getTransform());
						%obj.mountImage(ScoutChaingunParam, 0);
						%obj.mountImage(ScoutChaingunImage, 2);
						%obj.mountImage(ScoutChaingunPairImage, 3);
						%obj.nextWeaponFire = 2;
// Tank Chaingun
				} else if (%player.invAmmoPack) {
					%obj.mountImage(GatlinGunBarrel, 0);
// Tank Mortar
				} else if (%player.invShieldPack) {
					%obj.mountImage(ShockwaveMortarBarrel, 0);
// Sockwave Gun
				} else if (%player.invSensorJammerPack) {
					%obj.mountImage(BomberMortarBarrel, 0);
// Smoke Gun
				} else if (%player.invSatchelCharge) {
					%obj.mountImage(SmokeScreenGunBarrel, 0);
//				} else {
//						error("No clue what to do with pack - " @ %player.client.favorites[%player.client.packIndex]);
				}
			}
		}
	}
};