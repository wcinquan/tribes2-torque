

//------------vspawn code by sparky----------
//-------------------V1.0.0---------------------
//------------special effects by TseTse--------
//---this is where I create the triggers and put them right over the nexus base's

$playerreject = 6;

function createNewvspawnTriggers(%vspawngroup)
{

// get groupid

   $vspawngroup = nametoid(%vspawngroup);

//----get all objects in group------

    %telecount = $vspawngroup.getcount();
       for ( %i = 0; %i < $vspawngroup.getCount(); %i++ )
          {
             %tp = $vspawngroup.getObject( %i );
                %trigger = new Trigger()
                {
                   dataBlock = NewVspawnTrigger;
                   polyhedron = "-0.75 0.75 0.1 1.5 0.0 0.0 0.0 -1.5 0.0 0.0 0.0 2.3";
                };

            MissionCleanup.add(%trigger);
            %trigger.setTransform(%tp.getTransform());
            %trigger.message = %tp.message;
            %trigger.logoscale = %tp.logoscale;
            %tp.trigger = %trigger;
            %trigger.vehicle = %tp.vehicle;

           %tp.playThread(1, "ambient");
            %tp.playThread(0, "transition");
            %tp.playThread(0, "ambient");


            %newHolo = getTaggedString(game.getTeamSkin(%trigger.team)) @ "Logo";
                %teleholo1 = getTaggedString(game.getTeamSkin(1)) @ "Logo";
                %teleholo2 = getTaggedString(game.getTeamSkin(2)) @ "Logo";

//            %newHolo = "testLogo";
            %pos = %trigger.position;

       if(%trigger.logoscale !$= "")
          {
             if(%trigger.team != 0)
                {
         %holo = new StaticShape()
             {
             rotation = rotfromtransform(%trigger.gettransform());
             position = getWord(%pos,0) @ " " @ getWord(%pos,1) @ " " @ getWord(%pos,2) + 1;
             dataBlock = %newHolo;
             scale = %trigger.logoscale;
             };
      // dump the hologram into MissionCleanup
             MissionCleanup.add(%holo);
//             }
      // associate the holo with the teleporter
        %trigger.sourcebase.holo = %holo;

             }
          }


        }
}

activatePackage(vspawn);

datablock TriggerData(NewVspawnTrigger)
{
   tickPeriodMS = 30;
};
//--------------teleporter code here------------------

createNewvspawnTriggers("MissionGroup/vspawns");

package vspawn {



function setPlayersPosition2(%data, %obj, %trigger, %colObj)
{
   %vel = getWords(%colObj.getVelocity(), 0, 1) @ " 0";
   if((VectorLen(%vel) < 22) && (%obj.triggeredBy != %colObj))
   {
      %pos = %trigger.position;
      %colObj.setvelocity("0 0 0");
	   %rot = getWords(%colObj.getTransform(),3, 6);
      %colObj.setTransform(getWord(%pos,0) @ " " @ getWord(%pos,1) @ " " @ getWord(%pos,2) + 0.8 @ " " @ %rot);  //center player on object  
      %colObj.setMoveState(true);
//      %colObj.schedule(1300,"setMoveState", false);
//
//      %colObj.schedule(1300,"setvelocity" , "5 5 5");
      return true;
   }
   return false;
}

function NewVspawnTrigger::onEnterTrigger(%data, %trigger, %player)
{
 %colObj = %player;
      %client = %player.client;



        setPlayersPosition2(%data, %obj, %trigger, %colObj);




           if(%trigger.message !$= "")
      	           messageClient(%Player.client, 'MsgClient', "\c0 " @ %trigger.message);

           %rot = rotFromTransform( %player.getTransform() );
//           %player.startfade(500,0,true);
           teleporteffect(posfromtransform(%player.gettransform()));
           %pos = posFromTransform(%trigger.getTransform() );

		%x = getword(%pos, 0); 			// left of center
		%y = getword(%pos, 1);			// "forward" adjustment
		%z = getword(%pos, 2) + 0.5; 		// VERTICLE
		%exitpos = %x SPC %y SPC %z;		// new position
           teleporteffect(%exitpos);
            %pos = %trigger.position;
            createRaceVehicle(%player.client, 0, %trigger.vehicle, 0 , getWord(%pos,0) @ " " @ getWord(%pos,1) @ " " @ getWord(%pos,2) + 1, rotfromtransform(%trigger.gettransform()), 30);
            %colObj.schedule(1000, "setmovestate", false);



}

function NewVspawnTrigger::onleaveTrigger(%data, %trigger, %player)
{
}

function NewVspawnTrigger::onTickTrigger(%data, %obj)
{
   Game.onTickTrigger(%obj.name, %data, %obj);
}

function teleporteffect(%position)
{
//       for ( %i = 0; %i < 4 %i++ )
//   {
           %pos = %position;
//echo("the object is number " @ %obj );

	%effect1 = new ParticleEmissionDummy()
            {
		       position = %pos;
		       rotation = "1 0 0 0";
         		scale = "1 1 1";
         		dataBlock = "doubleTimeEmissionDummy";
         		lockCount = "0";
         		homingCount = "0";
         		emitter = "AABulletExplosionEmitter2";
         		velocity = "1";
         	};
	%effect2 = new ParticleEmissionDummy()
            {
		       position = getWord(%pos,0) @ " " @ getWord(%pos,1) @ " " @ getWord(%pos,2) + 0.5;
		       rotation = "1 0 0 0";
         		scale = "1 1 1";
         		dataBlock = "doubleTimeEmissionDummy";
         		lockCount = "0";
         		homingCount = "0";
         		emitter = "AABulletExplosionEmitter2";
         		velocity = "1";
         	};

	%effect3 = new ParticleEmissionDummy()
            {
		       position = getWord(%pos,0) @ " " @ getWord(%pos,1) @ " " @ getWord(%pos,2) + 1;
		       rotation = "1 0 0 0";
         		scale = "1 1 1";
         		dataBlock = "doubleTimeEmissionDummy";
         		lockCount = "0";
         		homingCount = "0";
         		emitter = "AABulletExplosionEmitter2";
         		velocity = "1";
         	};
	%effect4 = new ParticleEmissionDummy()
            {
		       position = getWord(%pos,0) @ " " @ getWord(%pos,1) @ " " @ getWord(%pos,2) + 1.5;
		       rotation = "1 0 0 0";
         		scale = "1 1 1";
         		dataBlock = "doubleTimeEmissionDummy";
         		lockCount = "0";
         		homingCount = "0";
         		emitter = "AABulletExplosionEmitter2";
         		velocity = "1";
         	};
            MissionCleanup.add(%effect1);
            MissionCleanup.add(%effect2);
            MissionCleanup.add(%effect3);
            MissionCleanup.add(%effect4);
            %effect1.schedule(2000, "delete");
            %effect2.schedule(2000, "delete");
            %effect3.schedule(2000, "delete");
            %effect4.schedule(2000, "delete");

}
function createRaceVehicle(%client, %station, %blockName, %team , %pos, %rot, %angle)
{
   %obj = %blockName.create(%team);
   if(%obj)
   {
      %station.ready = false;
      %obj.team = %team;
      %obj.useCreateHeight(true);
 //     %obj.schedule(100, "useCreateHeight", false);
      %obj.getDataBlock().isMountable(%obj, false);
      %obj.getDataBlock().schedule(100, "isMountable", %obj, true);

//      %station.playThread($ActivateThread,"activate2");
//      %station.playAudio($ActivateSound, ActivateVehiclePadSound);

      vehicleListAdd(%blockName, %obj);
      MissionCleanup.add(%obj);

      %turret = %obj.getMountNodeObject(10);
      if(%turret > 0)
      {
         %turret.setCloaked(true);
         %turret.schedule(4800, "setCloaked", false);
      }
           %scflyerpos = posFromTransform(%client.player.getTransform());

		%x = getword(%pos, 0); 			// left of center
		%y = getword(%pos, 1);			// "forward" adjustment
		%z = getword(%pos, 2) + 10; 		// VERTICLE
		%exitpos = %x SPC %y SPC %z;		// new position

      %obj.setCloaked(true);
      %obj.setTransform(%pos @ " " @ %rot @ " " @ %angle);
      if(%blockname $= "scoutflyer")
                     %obj.setTransform(%exitpos @ " " @ %rot @ " " @ %angle);

      %obj.schedule(700, "playAudio", 0, VehicleAppearSound);
      %obj.schedule(100, "setCloaked", false);

      if(%client.player.lastVehicle)
      {
         %client.player.lastVehicle.lastPilot = "";
         vehicleAbandonTimeOut(%client.player.lastVehicle);
         %client.player.lastVehicle = "";
      }
      %client.player.lastVehicle = %obj;
      %obj.lastPilot = %client.player;


      if ( %client.isVehicleTeleportEnabled() )
         %obj.getDataBlock().schedule(100, "mountDriver2", %obj, %client.player);
//         %obj.getDataBlock().mountDriver2(%obj, %client.player);
   }
   if(%obj.getTarget() != -1)
      setTargetSensorGroup(%obj.getTarget(), %client.getSensorGroup());
   // We are now closing the vehicle hud when you buy a vehicle, making the following call
   // unnecessary (and it breaks stuff, too!)
   //VehicleHud.updateHud(%client, 'vehicleHud');
}
function VehicleData::mountDriver2(%data, %obj, %player)
{
   if(isObject(%obj) && %obj.getDamageState() !$= "Destroyed")
   {
      schedule(100, 0, "testVehicleForMount", %player, %obj);
   }
}

};
//Teleport code ends here----------------------------------------


