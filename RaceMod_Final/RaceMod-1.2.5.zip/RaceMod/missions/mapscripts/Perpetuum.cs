datablock StaticShapeData(RaceSwitch)
{
   catagory = "Objectives";
   shapefile = "Raceswitch.dts";

   isInvincible = true;
   cmdCategory = "Racing Items";
   cmdIcon = "CMDSwitchIcon";
   cmdMiniIconName = "commander/MiniIcons/com_switch_grey";
   targetTypeTag = 'Switch';
   alwaysAmbient = true;
   needsNoPower = true;
   emap = true;
};


package Perpetuum
{
   function Perpetuum::preLoad(%firstMission)
   {
      echo("preLoad Perpetuum: packages activated");
      // --------------------------------------------------------------------
      // --------------------------------------------------------------------
      // Call to included abydos scripting
      // if(isPackage(abydosPack))

   }

   function Perpetuum::InitMap()
   {
      echo("InitMap Perpetuum");
   }

   function Perpetuum::DeactivateMap()
   {
      echo("DeactivateMap Perpetuum");
      $Map::MyMap = "";
   }


function RaceSwitch::onCollision(%data,%obj,%col)
{
   if (%col.getDataBlock().className $= Armor && %col.getState() !$= "Dead")
      %data.playerTouch(%obj, %col);
}

function RaceSwitch::playerTouch(%data,%obj,%col)
{
   messageAll('MsgPlayerTouchSwitch', 'Player %1 touched switch %2', %col, %obj);
}


function DefaultGame::pickTeamSpawn(%game, %team)
{                                                               // SIMPLE CODE based on jailbreak and obesrver drops
echo("...... Perpetuum Spawn Interpulation Machine Activated");

   // %group = nameToID("MissionGroup/Teams/team" @ %team @ "/DreadSpawn");
   %group = nameToID("MissionGroup/Teams/DreadSpawn");
   if(isObject(%group))
   {
      %count = %group.getCount();
      if(%count)
      {
         %index = mFloor(getRandom(0, %count - 1));
         %obj = %group.getObject(%index);
         %spawnLoc =  %obj.getTransform();
         return;

      }
      else
      {
         error("Perpetuum: Could not find a spawn point.");
         return "0 0 400";
      }
   }
   else
   {
      error("Perpetuum: No spawn group found.");
      return "0 0 400";
   }

// parent::pickTeamSpawn(%game, %team);

}

   

};  // end package



