
datablock StaticShapeData(ccbFlop)
{
   isInvincible = true;
   cmdCategory = "Support";
   shapefile = "switch.dts";
   cmdIcon = "CMDSwitchIcon";
   cmdMiniIconName = "commander/MiniIcons/com_switch_grey";
   targetNameTag = 'Spawn';
   targetTypeTag = 'LinkSwitch';
   ambientThreadPowered = true;
   needsNoPower = false;
   humSound = StationInventoryHumSound;
   computeCRC = true;
   emap = true;
};


function DefaultGame::ccbSelectSpawnSphere(%game, %client)
{
   // - walks the objects in the 'teamdrops' group for this team
   // - and finds the client designated spawnsphere

   %group = nameToID("MissionCleanup/TeamDrops" @ %client.team);
   if (%group != -1)
   {
      %count = %group.getCount();
      if (%count != 0)
      {
         for (%i = 0; %i < %count; %i++)
         {
            %sphereObj = %group.getObject(%i);
            if (! %sphereObj.isHidden())
               if (%sphereObj.ccbSphereNum == %client.ccbSphereNum)
                  return %group.getObject(%i);
         }
      }
   }
   return -1;
}

function DefaultGame::ccbPickTeamSpawn(%game, %client)
{
   // early exit if no nav graph
   if (!navGraphExists())
   {
      echo("No navigation graph is present.  Build one.");
      return -1;
   }

   for (%attempt = 0; %attempt < 20; %attempt++)
   {
      %sphere = %game.ccbSelectSpawnSphere(%client);
      if (%sphere == -1)
      {
         echo("No spawn spheres found for team " @ %client.team);
         return -1;
      }

      %zone = %game.selectSpawnZone(%sphere);
      %useIndoor = %zone;
      %useOutdoor = !%zone;
      if (%zone)
         %area = "indoor";
      else
         %area = "outdoor";

      %radius = %sphere.radius;
      %sphereTrans = %sphere.getTransform();
      %sphereCtr = getWord(%sphereTrans, 0) @ " " @ getWord(%sphereTrans, 1) @ " " @ getWord(%sphereTrans, 2);   //don't need full transform here, just x, y, z
      //echo("Selected Sphere is " @ %sphereCtr @ " with a radius of " @ %radius @ " meters.  Selecting from " @ %area @ " zone.");

      %avoidThese = $TypeMasks::VehicleObjectType  | $TypeMasks::MoveableObjectType |
                    $TypeMasks::PlayerObjectType   | $TypeMasks::TurretObjectType;

      for (%tries = 0; %tries < 10; %tries++)
      {
         %nodeIndex = navGraph.randNode(%sphereCtr, %radius, %useIndoor, %useOutdoor);
         if (%nodeIndex >= 0)
         {
            %loc = navGraph.randNodeLoc(%nodeIndex);
            %adjUp = VectorAdd(%loc, "0 0 1.0");   // don't go much below

            if (ContainerBoxEmpty( %avoidThese, %adjUp, 2.0))
               break;
         }
      }

      if (%nodeIndex >= 0)
      {
         %loc = navGraph.randNodeLoc(%nodeIndex);
         if (%zone)
         {
            %trns = %loc @ " 0 0 1 0";
            %spawnLoc = whereToLook(%trns);
         }
         else
         {
            %rot = %game.selectSpawnFacing(%loc, %sphereCtr, %zone);
            %spawnLoc = %loc @ %rot;
         }
         return %spawnLoc;
      }
   }
}


function ccbintro()
{
   %message = "<color:0EAEE3>\Select spawnspheres by touching LinkSwitches\nLoss of power deactivates main spawnspheres\nOnce powered is restored, you must relink to your desired spawnsphere";
   centerPrintAll( %message, 12, 3 );
  }

function ccbFlop::onCollision(%data,%obj,%col)
{
   if (%col.getDataBlock().className $= Armor && %col.getState() !$= "Dead")
   {
      %data.playerTouch(%obj, %col);
   }
}

function ccbFlop::playerTouch(%data,%obj,%col)
{
   if (! %obj.isPowered())
   {
      messageClient(%col.client, 'Msg', '\c2Switch is not powered.');
      return;
   }
   if (%obj.team == %col.team)
   {
      %ccbName = getTaggedString(%obj.nameTag);
      if (%col.client.ccbSphereNum == %obj.ccbSphereNum)
      {
         bottomPrint(%col.client, "<color:BA7007>\Link Failed -- Already linked to " @ %ccbName @ "Sphere.", 5, 1);
         messageClient(%col.client, 'Msg', '~wfx/misc/misc.error.wav');
         return;
      }
      else
      {

         %col.client.ccbSphereNum = %obj.ccbSphereNum;
         bottomPrint(%col.client, "<color:FFE505>\Successfully linked with the " @ %ccbName @ "Sphere.", 5, 1);
         messageClient(%col.client, 'Msg', '~wfx/misc/target_waypoint.wav');
         return;
      }
   }
   else
   {
      messageClient(%col.client, 0, '\c2Access Denied -- Wrong team.~wfx/powered/station_denied.wav');
      return;
   }
}


////////////////////////////////////////////////////////////////////////////////
// PACKAGE

package ziggurat
{

   function ziggurat::preLoad(%firstMission)
   {
      echo("preLoad ziggurat: packages activated");


   $DefaultVehicleMax[ScoutVehicle]     = $Vehiclemax[ScoutVehicle];
   $DefaultVehicleMax[AssaultVehicle]   = $Vehiclemax[AssaultVehicle];
   $DefaultVehicleMax[MobileBaseVehicle]= $Vehiclemax[MobileBaseVehicle];
   $DefaultVehicleMax[ScoutFlyer]       = $Vehiclemax[ScoutFlyer];
   $DefaultVehicleMax[BomberFlyer]      = $Vehiclemax[BomberFlyer];
   $DefaultVehicleMax[HAPCFlyer]        = $Vehiclemax[HAPCFlyer];

   $VehicleMax[ScoutVehicle]     = 4;
   $VehicleMax[AssaultVehicle]   = 3;
   $VehicleMax[MobileBaseVehicle]= 2;
   $VehicleMax[ScoutFlyer]       = 2;
   $VehicleMax[BomberFlyer]      = 1;
   $VehicleMax[HAPCFlyer]        = 2;

   game.schedule(($Host::WarmUpTime * 1000) + 5000, 0, ccbintro());

   }

   function ziggurat::InitMap()
   {
      echo("InitMap ziggurat");
   }

   function ziggurat::DeactivateMap()
   {
      echo("DeactivateMap ziggurat");

            $Map::MyMap = "";
            
        $VehicleMax[ScoutVehicle]     = $DefaultVehiclemax[ScoutVehicle];
        $VehicleMax[AssaultVehicle]   = $DefaultVehiclemax[AssaultVehicle];
        $VehicleMax[MobileBaseVehicle]= $DefaultVehiclemax[MobileBaseVehicle];
        $VehicleMax[ScoutFlyer]       = $DefaultVehiclemax[ScoutFlyer];
        $VehicleMax[BomberFlyer]      = $DefaultVehiclemax[BomberFlyer];
        $VehicleMax[HAPCFlyer]        = $DefaultVehiclemax[HAPCFlyer];

   }
   

};   // end package


